const STATE_KEY = "extabilifyState";

const DEFAULT_STATE = {
  contrast:      false,
  textScale:     1,
  spacing:       false,
  focusMode:     false,
  screenReader:  false,
  speechRate:    1,
  speechPitch:   1,
  voiceURI:      "",
  voiceCommand:  true,
  hoverDelay:    500,
  highlightColor: "#f59e0b",
  smartReader:   false
};

const state = { ...DEFAULT_STATE };

const elements = {
  toggleButtons: [...document.querySelectorAll("[data-setting]")],
  fontScaleValue: document.getElementById("fontScaleValue"),
  decreaseText:   document.getElementById("decreaseText"),
  increaseText:   document.getElementById("increaseText"),
  speakSelection: document.getElementById("speakSelection"),
  micBtn:         document.getElementById("micBtn"),
  startQuiz:      document.getElementById("startQuiz"),
  reset:          document.getElementById("reset"),
  openOptions:    document.getElementById("openOptions"),
  status:         document.getElementById("status")
};

function clamp(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); }

function storageGetState() {
  return new Promise(resolve => {
    chrome.storage.local.get({ [STATE_KEY]: DEFAULT_STATE }, items =>
      resolve({ ...DEFAULT_STATE, ...(items[STATE_KEY] || {}) }));
  });
}

function storageSetState(nextState) {
  return new Promise(resolve =>
    chrome.storage.local.set({ [STATE_KEY]: nextState }, resolve));
}

function setStatus(msg) { elements.status.textContent = msg; }

function prettyLabel(key) {
  return {
    contrast:     "Sharper screen",
    spacing:      "Reading space",
    focusMode:    "Clear the page",
    screenReader: "Voice guide",
    voiceCommand: "Voice commands",
    smartReader:  "Smart reading"
  }[key] || key;
}

function render() {
  for (const btn of elements.toggleButtons) {
    const key = btn.dataset.setting;
    const on  = key === "textScale" ? state.textScale !== 1 : Boolean(state[key]);
    btn.setAttribute("aria-pressed", String(on));
  }
  elements.fontScaleValue.textContent = `${Math.round(state.textScale * 100)}%`;

  // Mic button visual state
  if (elements.micBtn) {
    elements.micBtn.classList.toggle("active", Boolean(state.voiceCommand));
    elements.micBtn.setAttribute("aria-pressed", String(Boolean(state.voiceCommand)));
  }
}

async function persistAndRender(msg) {
  await storageSetState({ ...state });
  render();
  if (msg) setStatus(msg);
}

function toggleSetting(key) {
  state[key] = !state[key];
  return persistAndRender(`${prettyLabel(key)} is ${state[key] ? "on" : "off"}.`);
}

function updateTextScale(delta) {
  state.textScale = Number(clamp((state.textScale || 1) + delta, 0.8, 2.0).toFixed(2));
  return persistAndRender(`Letters are now ${Math.round(state.textScale * 100)}% size.`);
}

function getActiveTab() {
  return new Promise(resolve =>
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => resolve(tabs[0] || null)));
}

function sendTabMessage(tabId, message) {
  return new Promise(resolve => {
    chrome.tabs.sendMessage(tabId, message, response => {
      resolve({ response, error: chrome.runtime.lastError?.message || "" });
    });
  });
}

function injectContentScript(tabId) {
  return new Promise(resolve => {
    if (!chrome.scripting?.executeScript) {
      resolve({ ok: false, error: "Programmatic injection is not available." });
      return;
    }
    chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }, () => {
      const error = chrome.runtime.lastError?.message || "";
      resolve({ ok: !error, error });
    });
  });
}

async function sendTabMessageReady(tabId, message) {
  let result = await sendTabMessage(tabId, message);
  if (!result.error) return result.response;

  const injected = await injectContentScript(tabId);
  if (!injected.ok) throw new Error(injected.error || result.error);

  result = await sendTabMessage(tabId, message);
  if (result.error) throw new Error(result.error);
  return result.response;
}

async function startQuizMode() {
  if (!state.smartReader) {
    state.smartReader = true;
    await persistAndRender("Smart reading on. Looking for quiz questions…");
  }
  const tabId = (await getActiveTab())?.id;
  if (!tabId) { setStatus("Please open a webpage first."); return; }

  sendTabMessageReady(tabId, { type: "EXTABILIFY_START_EXAM" }).then(response => {
    if (response?.ok) {
      setStatus(`Quiz mode started — ${response.count} question${response.count === 1 ? "" : "s"} found. Listen to your device.`);
      window.close();
    } else {
      setStatus("No multiple-choice questions were found on this page.");
    }
  }).catch(() => {
    setStatus("Could not start quiz mode on this page. Reload the page and try again.");
  });
}

async function resetState() {
  Object.assign(state, DEFAULT_STATE);
  await persistAndRender("All settings reset to normal.");
}

async function readSelection() {
  const tabId = (await getActiveTab())?.id;
  if (!tabId) { setStatus("Please open a webpage and highlight some text first."); return; }

  chrome.runtime.sendMessage({ type: "EXTABILIFY_READ_SELECTION", tabId }, response => {
    if (chrome.runtime.lastError) { setStatus("This page cannot be used with Extabilify."); return; }
    setStatus(response?.ok ? response.message || "Reading now..." : response?.message || "Please highlight some text first.");
  });
}

async function triggerVoiceCommand() {
  // First make sure voice commands are enabled
  if (!state.voiceCommand) {
    state.voiceCommand = true;
    await persistAndRender("Voice commands on. Listening now...");
  }

  const tabId = (await getActiveTab())?.id;
  if (!tabId) { setStatus("Please open a webpage first."); return; }

  chrome.tabs.sendMessage(tabId, { type: "EXTABILIFY_START_VOICE_CMD" }, response => {
    if (chrome.runtime.lastError) {
      sendTabMessageReady(tabId, { type: "EXTABILIFY_START_VOICE_CMD" }).then(() => {
        setStatus("Listeningâ€¦ speak your command.");
        window.close();
      }).catch(() => {
        setStatus("Could not start voice command on this page. Reload the page and try again.");
      });
    } else {
      setStatus("Listening… speak your command.");
      window.close(); // close popup so mic has focus on the page
    }
  });
}

async function init() {
  const saved = await storageGetState();
  Object.assign(state, saved);
  render();

  for (const btn of elements.toggleButtons) {
    btn.addEventListener("click", () => {
      const key = btn.dataset.setting;
      if (key === "textScale") {
        state.textScale = state.textScale === 1 ? 1.1 : 1;
        persistAndRender(`Letters are now ${Math.round(state.textScale * 100)}% size.`);
        return;
      }
      toggleSetting(key);
    });
  }

  elements.decreaseText.addEventListener("click", () => updateTextScale(-0.1));
  elements.increaseText.addEventListener("click", () => updateTextScale(0.1));
  elements.speakSelection.addEventListener("click", readSelection);
  elements.micBtn?.addEventListener("click", triggerVoiceCommand);
  elements.startQuiz?.addEventListener("click", startQuizMode);
  elements.reset.addEventListener("click", resetState);
  elements.openOptions.addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
    setStatus("Opening your settings…");
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes[STATE_KEY]) return;
    Object.assign(state, DEFAULT_STATE, changes[STATE_KEY].newValue || {});
    render();
  });
}

init();
