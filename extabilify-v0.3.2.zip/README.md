# Extabilify

> *Every student in Ghana deserves to navigate the web on their own terms.*

Extabilify is a free, open-source browser extension built to help students with special needs — visual impairments, reading difficulties, dyslexia, low vision, and other learning differences — access the internet for learning. It runs entirely inside the browser, requires no server, no account, and no internet connection beyond the page being read.

It was built with one long-term mission in mind: to become a **fully African-language-powered, voice-guided learning companion** that makes educational technology genuinely inclusive for every student on the continent — starting in Ghana.

---

## Why this exists

Ghana has had a disability law since 2006. The Ghana Education Service has a Special Education Division. Schools for the blind, deaf, and students with learning differences exist in every region. And yet, when a student with visual impairment sits down at a computer in a school lab — at GISE, at Wa School for the Blind, at Akropong, at any JHS or SHS trying to include students with different needs — the web does not speak to them. Most educational platforms, WAEC portals, and digital learning materials offer nothing for the student who cannot read a screen clearly, process dense text quickly, or navigate without assistance.

The assistive technology that exists was built for English-speaking, Western markets. NVDA and JAWS are powerful but cost money, require Windows, and speak no Ghanaian language. TalkBack on Android helps, but when a school has a computer lab and a student needs to access GES materials, submit an assignment, or read an e-textbook, there is no simple, local, free tool.

Extabilify starts filling that gap today, with what is already possible in a browser. The vision is bigger.

---

## What it does right now

| Feature | What it means for a student |
|---|---|
| **Voice guide** | Narrates every element the student hovers over or tabs through — buttons, links, forms, headings — so they can navigate without seeing clearly |
| **Voice commands** | Control any page by speaking — "scroll down", "dark mode", "find [word]", "click submit", "help" — like a mobile voice assistant, for students who cannot use a mouse or keyboard |
| **Smart reading** | Repairs pages built without accessibility markup: labels unlabelled buttons, adds alt text to images, marks headings and page sections, and finds quiz questions — so the voice guide works even on portals a normal screen reader cannot read |
| **Quiz mode** | On multiple-choice pages, reads each question and its lettered options then listens automatically — the student just says the letter ("B", "choose B", "bravo"), and it selects the radio/checkbox and moves to the next question. Also "next", "back", "repeat", "go to question 3", "submit" (warns about blanks first) |
| **My voice profile** | The student records their own voice saying the confirmation phrases, and the extension plays those back instead of the robotic voice |
| **Read this aloud** | Highlights any text and reads it aloud in the student's preferred voice and speed |
| **Browser zone tracking** | When the mouse leaves the page, announces where it went — address bar, back button, window controls — so a student with low vision always knows where they are |
| **Sharper screen** | High-contrast dark mode that makes text and colour much easier to see |
| **Bigger letters** | Scales text from 80% to 200% across any page |
| **Reading space** | Increases line height, letter spacing, and word spacing for students who struggle with dense text |
| **Clear the page** | Strips adverts, navigation bars, sidebars, and cookie banners so only the content remains |
| **Adjustable hover delay** | For students with hand tremors — set how long the cursor must rest before the voice guide speaks |
| **Right-click menu** | Every feature accessible without opening the popup — useful for students with limited motor control |
| **Keyboard shortcuts** | `Alt+Shift+D` describe focused element · `Alt+Shift+R` toggle voice guide · `Alt+Shift+M` speak a command · `Alt+Shift+Q` start/stop quiz mode · `Alt+Shift+N`/`P` next/previous question · `Alt+Shift+1–9` pick an option |
| **Settings page** | Students set their defaults once — voice speed, pitch, text size, preferred helpers — and the extension remembers |

Everything works offline. No data leaves the student's device.

---

## Who it is for

**Right now:**
- Students with visual impairments in Ghanaian schools
- Students with dyslexia, low vision, or reading difficulties
- Students with physical disabilities who navigate primarily by keyboard
- Teachers and support staff at special needs schools who want to demo tools without installing heavy software

**As it grows:**
- Any school in Ghana or across Africa introducing accessible computing
- Developers and researchers building on a local, open foundation
- Parents helping children with learning differences use the web at home

---

## The bigger vision

What exists today is a foundation. The mission it is building toward is this:

**An African-language-powered screen reader and learning companion — free, open source, and built for the classroom.**

That means:

### 1. Ghanaian and African language TTS
Twi, Ga, Dagbani, Hausa, Ewe, and other languages spoken by students in Ghana should be languages a screen reader can speak — not just English. Students learn better when they hear instructions in a language they grew up with. This requires building or adopting open TTS models trained on African languages. Projects like [GhanaNLP](https://ghananlp.org) and [Masakhane](https://www.masakhane.io) are already doing this work. Extabilify intends to integrate those models as they become production-ready.

### 2. Page-aware reading for school platforms
GES portals, WAEC result checkers, BECE and WASSCE prep sites, and national e-learning platforms like those being rolled out under Ghana's digital education agenda should work seamlessly with a screen reader built for Ghanaian students. The **smart reading engine** is the first step: it already infers roles, labels and structure on the fly. Next is tuning its heuristics against a corpus of real Ghanaian school pages for more context-aware narration.

### 3. Form and assessment assistance
Many students with disabilities struggle not with content but with interacting with forms — selecting answers, submitting assignments, navigating exam interfaces. **Quiz mode** delivers the first piece: on multiple-choice pages it reads each question and its options and confirms every answer by voice before submission, warning about blanks. Next is extending the same audio-guided, confirm-before-submit approach to text-entry forms and assignment upload interfaces.

### 4. Teacher and school admin tools
A companion dashboard for teachers to see which accessibility tools their students are using, flag pages that fail basic accessibility standards, and receive suggestions for making their own materials more inclusive.

### 5. Offline-first, low-bandwidth architecture
Ghana's network connectivity is uneven. The final version of Extabilify must work fully offline — voices cached locally, content readable without a live connection, settings synced when connectivity returns.

---

## The impact this seeks to create

Ghana has approximately 3 million people living with disabilities, and educational exclusion begins early. Children with visual impairments who reach secondary school often do so with less support than their peers. Students with dyslexia are frequently misidentified as slow learners. The digital divide hits students with special needs first and hardest.

Extabilify's measurable goals are:

- **Reduce the barrier to accessing digital learning materials** for students with visual and reading disabilities in Ghanaian schools
- **Equip teachers** with a free, installable tool that requires no training budget and no IT infrastructure to deploy
- **Create a local open-source reference** that Ghanaian developers, researchers, and education technologists can build on — rather than depending on tools built elsewhere for other contexts
- **Demonstrate to the Ghana Education Service and educational NGOs** that accessible, local, browser-based assistive technology is both possible and practical
- **Plant the seed for a pan-African accessibility layer** — the same architecture that works for Ghanaian students in Twi and English can be extended for Yoruba, Amharic, Swahili, Zulu, and every other language in which a student deserves to learn

---

## How to install it (for schools and testers)

No app store submission yet — this is an early version. Here is how to load it manually in Chrome or any Chromium-based browser (including Microsoft Edge):

1. Download or clone this repository to a computer
2. Open Chrome and go to `chrome://extensions`
3. Turn on **Developer mode** using the toggle in the top right
4. Click **Load unpacked**
5. Select the folder where you saved the Extabilify files
6. The extension icon will appear in your browser toolbar

To use it:
- Click the Extabilify icon to open the popup
- Turn on **Voice guide** for full narration
- Highlight any text and press **Read this aloud** to hear it spoken
- Right-click any page to access the Extabilify menu
- Click **Change my settings** to save your preferred voice, speed, and defaults

---

## How to contribute

This project is in active early development. Contributions are welcome from anyone who cares about accessible education in Ghana and Africa.

**Ways to help right now:**

- **Test it in a real school setting** and report what works and what does not
- **Improve element descriptions** — if a screen on a Ghanaian school portal is not being described well, open an issue with the URL and what was said vs. what should have been said
- **Write Twi, Ga, or other language strings** — help translate the UI and toast messages when multi-language support lands
- **Connect us with TTS researchers** working on Ghanaian language models
- **Share with a teacher or school** — the fastest way to find real problems is real usage

---

## Built with

- **Manifest V3** Chrome Extension APIs
- **Web Speech API** — browser-native TTS and speech recognition
- Plain HTML, CSS, and JavaScript — no frameworks, no build step, easy to read and modify
- Ghana flag colours: Gold `#FCD116` · Green `#006B3F`

## Standards basis

Extabilify's smart-reading engine repairs the semantics a page's author left out. What it
adds, and why, is grounded in a defined set of W3C accessibility specifications plus two
education standards. See **[docs/STANDARDS.md](docs/STANDARDS.md)** for the full reference
basis — which spec governs each part of the code, the accessible-name algorithm we follow,
the quiz-detection ladder (Schema.org → QTI → native HTML → heuristic), and why Extabilify
is deliberately *not* an accessibility overlay.

---

## Licence

MIT — free to use, modify, and redistribute. If you build something with it for Ghanaian or African students, we would love to hear about it.

---

*Extabilify — Built for Ghana. Built for every student.*
