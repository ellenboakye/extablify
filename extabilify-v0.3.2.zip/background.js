const STATE_KEY = "extabilifyState";
const AI_KEY = "extabilifyAiConfig";
const DEFAULT_AI_CONFIG = {
  enabled: false,
  provider: "openai",              // "openai" | "ollama"
  apiKey: "",                      // OpenAI only
  openaiModel: "gpt-4o-mini",
  ollamaUrl: "http://localhost:11434",
  ollamaModel: "llama3.1"
};

const DEFAULT_STATE = {
  contrast: false,
  textScale: 1,
  spacing: false,
  focusMode: false,
  screenReader: false,
  speechRate: 1,
  speechPitch: 1,
  voiceURI: "",
  voiceCommand: true,
  hoverDelay: 500,
  highlightColor: "#f59e0b",
  smartReader: false
};

const MENU_IDS = {
  root: "extabilify-root",
  readSelection: "extabilify-read-selection",
  toggleFocus: "extabilify-toggle-focus",
  openSettings: "extabilify-open-settings",
  reset: "extabilify-reset"
};

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function normalizeState(input) {
  const next = { ...DEFAULT_STATE, ...(input || {}) };

  return {
    contrast: Boolean(next.contrast),
    textScale: clamp(Number(next.textScale) || DEFAULT_STATE.textScale, 0.8, 2.0),
    spacing: Boolean(next.spacing),
    focusMode: Boolean(next.focusMode),
    screenReader: Boolean(next.screenReader),
    speechRate: clamp(Number(next.speechRate) || DEFAULT_STATE.speechRate, 0.5, 2),
    speechPitch: clamp(Number(next.speechPitch) || DEFAULT_STATE.speechPitch, 0, 2),
    voiceURI: typeof next.voiceURI === "string" ? next.voiceURI : "",
    voiceCommand: Boolean(next.voiceCommand),
    hoverDelay: clamp(Number(next.hoverDelay) || DEFAULT_STATE.hoverDelay, 100, 2000),
    highlightColor: typeof next.highlightColor === "string" ? next.highlightColor : DEFAULT_STATE.highlightColor,
    smartReader: Boolean(next.smartReader)
  };
}

function storageGetState() {
  return new Promise((resolve) => {
    chrome.storage.local.get({ [STATE_KEY]: DEFAULT_STATE }, (items) => {
      resolve(normalizeState(items[STATE_KEY]));
    });
  });
}

function storageSetState(state) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ [STATE_KEY]: normalizeState(state) }, resolve);
  });
}

function sendMessageToTab(tabId, message) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }

      resolve(response || { ok: true });
    });
  });
}

function getActiveTab() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
      resolve(tabs[0] || null);
    });
  });
}

async function requestSelectionFromTab(tabId) {
  const response = await sendMessageToTab(tabId, { type: "EXTABILIFY_GET_SELECTION" });
  if (!response?.ok) {
    return null;
  }

  return {
    text: typeof response.text === "string" ? response.text.trim() : "",
    lang: typeof response.lang === "string" && response.lang.trim() ? response.lang.trim() : "en-US",
    url: typeof response.url === "string" ? response.url : "",
    updatedAt: typeof response.updatedAt === "number" ? response.updatedAt : 0
  };
}

async function notifyTab(tabId, message) {
  if (!tabId) {
    return;
  }

  await sendMessageToTab(tabId, {
    type: "EXTABILIFY_SHOW_TOAST",
    message
  });
}

async function readSelectionFromTab(tabId) {
  const tab = tabId ? { id: tabId } : await getActiveTab();

  if (!tab?.id) {
    return { ok: false, message: "Please open a webpage first." };
  }

  const selection = await requestSelectionFromTab(tab.id);

  if (!selection?.text) {
    await notifyTab(tab.id, "Please highlight some text on the page first.");
    return { ok: false, message: "Please highlight some text on the page first." };
  }

  try {
    const response = await sendMessageToTab(tab.id, {
      type: "EXTABILIFY_SPEAK_TEXT",
      text: selection.text,
      lang: selection.lang
    });

    if (!response?.ok) {
      await notifyTab(tab.id, response?.message || "Could not read that. Please try again.");
      return {
        ok: false,
        message: response?.message || "Could not read that. Please try again."
      };
    }

    return { ok: true, message: "Reading now..." };
  } catch (error) {
    await notifyTab(tab.id, "Could not read that. Please try again.");
    return {
      ok: false,
      message: "Could not read that. Please try again.",
      error: error?.message || String(error)
    };
  }
}

function createMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: MENU_IDS.root,
      title: "Extabilify",
      contexts: ["page", "selection"]
    });

    chrome.contextMenus.create({
      id: MENU_IDS.readSelection,
      parentId: MENU_IDS.root,
      title: "Read selection aloud",
      contexts: ["selection"]
    });

    chrome.contextMenus.create({
      id: MENU_IDS.toggleFocus,
      parentId: MENU_IDS.root,
      title: "Toggle focus mode",
      contexts: ["page", "selection"]
    });

    chrome.contextMenus.create({
      id: MENU_IDS.openSettings,
      parentId: MENU_IDS.root,
      title: "Open settings",
      contexts: ["page", "selection"]
    });

    chrome.contextMenus.create({
      id: MENU_IDS.reset,
      parentId: MENU_IDS.root,
      title: "Reset accessibility tweaks",
      contexts: ["page", "selection"]
    });
  });
}

async function resetState() {
  await storageSetState(DEFAULT_STATE);
}

async function toggleFocusMode() {
  const state = await storageGetState();
  await storageSetState({
    ...state,
    focusMode: !state.focusMode
  });
}

chrome.runtime.onInstalled.addListener(() => {
  createMenus();

  chrome.storage.local.get([STATE_KEY], (items) => {
    if (!items[STATE_KEY]) {
      chrome.storage.local.set({ [STATE_KEY]: DEFAULT_STATE });
    }
  });
});

chrome.runtime.onStartup.addListener(() => {
  createMenus();
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === MENU_IDS.openSettings) {
    chrome.tabs.create({ url: chrome.runtime.getURL("options.html") });
    return;
  }

  if (info.menuItemId === MENU_IDS.reset) {
    await resetState();
    return;
  }

  if (info.menuItemId === MENU_IDS.toggleFocus) {
    await toggleFocusMode();
    return;
  }

  if (info.menuItemId === MENU_IDS.readSelection && tab?.id) {
    await readSelectionFromTab(tab.id);
  }
});

// ═══════════════════════════════════════════════════════════════
// AI-ASSISTED VOICE-COMMAND REFINEMENT (optional — OpenAI or a
// self-hosted Ollama server)
// ═══════════════════════════════════════════════════════════════
//
// content.js only ever reaches this after its own local, offline pattern
// matching (the VOICE_COMMAND_DICTIONARY) has already failed to resolve a
// spoken command — so this is purely a fallback for confused or unusual
// phrasing, not the primary path, and the extension keeps working fully
// offline for everyone who hasn't configured this.
//
// Two providers are supported, chosen in Settings:
//  - "openai": hosted, needs an API key, costs money per request, uses
//    OpenAI's structured function-calling to constrain the output.
//  - "ollama": a free, self-hosted server (https://ollama.com) running on
//    this device or the local network — no API key, no per-request cost,
//    nothing ever leaves the machine/LAN. Since tool/function-calling
//    reliability varies a lot across the many models Ollama can run, this
//    uses Ollama's own `format: "json"` mode instead (broadly supported)
//    and validates the returned JSON just as strictly as the OpenAI path.
//
// The model is given ONLY the transcript, the current scope (general/quiz),
// content-free structural metadata (question count/index, option count and
// letters, whether the page uses native inputs or custom ARIA widgets, plain
// landmark counts) — NEVER the question stem, NEVER option text, and NEVER
// anything about which option is correct. It is instructed to return one
// command id from the caller-supplied allow-list (never inventing one), and
// — only when it can't route the command at all — may also draft one short
// help `message` grounded in that structural metadata (e.g. "this page uses
// custom clickable boxes instead of real checkboxes"). Because it never sees
// question or option text, it has no quiz content to leak; the system prompt
// forbids it explicitly, and isSafeAiMessage() below is a second,
// independent check that refuses to relay anything that reads like it's
// stating or hinting at an answer, regardless of what the model produced.

const UNSAFE_AI_MESSAGE_PATTERNS = [
  /\bthe answer is\b/i, /\bcorrect answer\b/i, /\bright answer\b/i, /\bwrong answer\b/i,
  /\byou should (choose|pick|select|answer|say)\b/i,
  /\bi (recommend|suggest|think|believe)\b.*\b(option|answer|choice|choosing|picking)\b/i,
  /\boption\s+[a-j]\b.*\b(is|was)\b.*\b(correct|right|wrong|the answer)\b/i,
  /\b(correct|right)\s+(option|choice|letter)\b/i
];
function isSafeAiMessage(text) {
  if (!text || typeof text !== "string") return false;
  const trimmed = text.trim();
  if (!trimmed || trimmed.length > 240) return false;
  return !UNSAFE_AI_MESSAGE_PATTERNS.some((re) => re.test(trimmed));
}

function storageGetAiConfig() {
  return new Promise((resolve) => {
    chrome.storage.local.get({ [AI_KEY]: DEFAULT_AI_CONFIG }, (items) => {
      resolve({ ...DEFAULT_AI_CONFIG, ...(items[AI_KEY] || {}) });
    });
  });
}

function buildRoutingPrompt(transcript, scope, quizContext, pageContext, allowedActions) {
  const systemPrompt =
    "You are a strict voice-command router for an accessibility browser extension used by " +
    "students, some with mobility challenges, who cannot use a mouse or keyboard. " +
    (scope === "quiz"
      ? "The student is in the middle of a multiple-choice quiz. "
      : "The student is browsing a web page. ") +
    "Your ONLY job is to classify their spoken, possibly rambling or confused, sentence into " +
    "exactly one command id from the allowed list. Rules: " +
    "1) NEVER answer the student's question or reveal/confirm/hint at a quiz answer — you are " +
    "not given the correct answer and must not guess or invent one. " +
    "2) NEVER return a command id that is not in the allowed list. " +
    "3) If a command needs an argument (quiz_answer needs the option letter the student said, " +
    "quiz_goto needs the question number, find_text/click_label need the short phrase they " +
    "want to find or click), extract it as a short plain string in `arg`. Otherwise omit `arg`. " +
    "4) If nothing in the allowed list plausibly matches, return action \"no_match\". " +
    "5) Only choose quiz_answer if the student is clearly stating a choice for the CURRENT " +
    "question by letter/number/NATO word (e.g. \"bravo\", \"option two\") — never infer an " +
    "answer they did not actually say. " +
    "6) You are never given the question text or option text (only counts/letters/structure), " +
    "so you have no way to know or guess a correct answer — do not try. " +
    "7) ONLY when action is \"no_match\", you may optionally add a short (under 200 characters) " +
    "`message`: one sentence of concrete, structural help for the student, grounded only in the " +
    "provided scope/quizContext/pageContext (e.g. mention that this page uses custom clickable " +
    "boxes instead of native checkboxes, or that there are N questions and this is number K, or " +
    "which of the allowed commands might be worth trying). `message` must NEVER mention quiz " +
    "content, option text, correctness, or anything that sounds like an answer or a hint at one — " +
    "it may only describe structure, navigation, or which command to try. If you have nothing " +
    "concrete and structural to add, omit `message` entirely rather than inventing filler. " +
    "8) Respond with nothing but a single JSON object shaped exactly like " +
    "{\"action\": \"...\", \"arg\": \"...\", \"message\": \"...\"} — arg and message are optional, " +
    "omit them when not needed. No other text, no markdown, no explanation.";

  const userPrompt = JSON.stringify({
    transcript,
    scope,
    quizContext: quizContext || null,
    pageContext: pageContext || null,
    allowedActions
  });

  return { systemPrompt, userPrompt };
}

// ── OpenAI: hosted, needs a key, uses structured function-calling ─────────
async function callOpenAI(config, systemPrompt, userPrompt, actionEnum) {
  if (!config.apiKey) {
    return { ok: false, reason: "AI voice assist is set to OpenAI but no API key is saved — add one in Settings." };
  }
  let resp;
  try {
    resp = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${config.apiKey}`
      },
      body: JSON.stringify({
        model: config.openaiModel || DEFAULT_AI_CONFIG.openaiModel,
        temperature: 0,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        tools: [{
          type: "function",
          function: {
            name: "route_command",
            description: "Route the student's spoken command to exactly one known action.",
            parameters: {
              type: "object",
              properties: {
                action: { type: "string", enum: actionEnum },
                arg: { type: "string" },
                message: {
                  type: "string",
                  description: "Only with action \"no_match\": a short (<200 char) structural help sentence — never quiz content, never an answer or hint."
                }
              },
              required: ["action"],
              additionalProperties: false
            }
          }
        }],
        tool_choice: { type: "function", function: { name: "route_command" } }
      })
    });
  } catch (error) {
    return { ok: false, reason: "network error reaching OpenAI: " + (error?.message || String(error)) };
  }

  if (!resp.ok) return { ok: false, reason: `OpenAI request failed (${resp.status})` };

  let data;
  try { data = await resp.json(); } catch (error) {
    return { ok: false, reason: "could not parse OpenAI response" };
  }

  const toolCall = data?.choices?.[0]?.message?.tool_calls?.[0];
  if (!toolCall) return { ok: false, reason: "model did not return a routed command" };

  const raw = toolCall.function.arguments;
  let args;
  try { args = JSON.parse(raw); } catch (error) {
    return { ok: false, reason: "could not parse routed command", raw };
  }
  return { ok: true, args, raw };
}

// ── Ollama: free, self-hosted (https://ollama.com), no API key ────────────
// Tool/function-calling support varies a lot across the many models Ollama
// can run, so this relies on Ollama's own `format: "json"` mode instead
// (much more consistently supported) plus an explicit instruction in the
// prompt to return that exact JSON shape, and validates the result just as
// strictly as the OpenAI path below.
async function callOllama(config, systemPrompt, userPrompt) {
  const base = (config.ollamaUrl || DEFAULT_AI_CONFIG.ollamaUrl).replace(/\/+$/, "");
  const url = base + "/api/chat";
  let resp;
  try {
    resp = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: config.ollamaModel || DEFAULT_AI_CONFIG.ollamaModel,
        format: "json",
        stream: false,
        options: { temperature: 0 },
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ]
      })
    });
  } catch (error) {
    return {
      ok: false,
      reason: `Could not reach Ollama at ${url}. Is it running on this device? ` +
        `(${error?.message || String(error)})`
    };
  }

  if (!resp.ok) return { ok: false, reason: `Ollama request failed (${resp.status})` };

  let data;
  try { data = await resp.json(); } catch (error) {
    return { ok: false, reason: "could not parse Ollama response" };
  }

  const raw = data?.message?.content;
  if (!raw) return { ok: false, reason: "Ollama returned no content" };

  let args;
  try { args = JSON.parse(raw); } catch (error) {
    return { ok: false, reason: "model did not return valid JSON", raw };
  }
  return { ok: true, args, raw };
}

async function refineVoiceCommand({ transcript, scope, allowedActions, quizContext, pageContext }) {
  const config = await storageGetAiConfig();
  if (!config.enabled) {
    return { ok: false, reason: "AI voice assist is not enabled — turn it on in Settings." };
  }
  if (!Array.isArray(allowedActions) || !allowedActions.length) {
    return { ok: false, reason: "no allowed actions for this scope" };
  }

  const actionEnum = [...allowedActions, "no_match"];
  const { systemPrompt, userPrompt } = buildRoutingPrompt(transcript, scope, quizContext, pageContext, allowedActions);

  const result = config.provider === "ollama"
    ? await callOllama(config, systemPrompt, userPrompt)
    : await callOpenAI(config, systemPrompt, userPrompt, actionEnum);

  if (!result.ok) return result;
  const { args, raw } = result;

  if (!args.action || !actionEnum.includes(args.action)) {
    return { ok: false, reason: "model returned an unrecognized action", raw };
  }

  // Only a "no_match" response may carry a drafted message, and only once it
  // passes the same safety filter content.js applies again on its side —
  // belt and suspenders against ever relaying anything answer-shaped.
  const message = args.action === "no_match" && isSafeAiMessage(args.message) ? args.message.trim() : undefined;

  return { ok: true, action: args.action, arg: args.arg, message, raw };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message) return;

  if (message.type === "EXTABILIFY_READ_SELECTION") {
    readSelectionFromTab(message.tabId || null)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ ok: false, message: "Could not read that selection.", error: error?.message || String(error) }));
    return true;
  }

  if (message.type === "EXTABILIFY_OPEN_SETTINGS") {
    chrome.tabs.create({ url: chrome.runtime.getURL("options.html") });
    sendResponse({ ok: true });
    return;
  }

  if (message.type === "EXTABILIFY_AI_REFINE") {
    refineVoiceCommand(message)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ ok: false, reason: error?.message || String(error) }));
    return true;
  }
});
