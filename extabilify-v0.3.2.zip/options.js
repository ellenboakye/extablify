const STATE_KEY = "extabilifyState";
const VP_KEY    = "extabilifyVoiceProfile";
const AI_KEY    = "extabilifyAiConfig";

const DEFAULT_AI_CONFIG = {
  enabled: false,
  provider: "openai",
  apiKey: "",
  openaiModel: "gpt-4o-mini",
  ollamaUrl: "http://localhost:11434",
  ollamaModel: "llama3.1"
};

const DEFAULT_STATE = {
  contrast:       false,
  textScale:      1,
  spacing:        false,
  focusMode:      false,
  screenReader:   false,
  speechRate:     1,
  speechPitch:    1,
  voiceURI:       "",
  voiceCommand:   true,
  hoverDelay:     500,
  highlightColor: "#f59e0b",
  smartReader:    false
};

// ── Phrases the user can record in their own voice ─────────────────────────
const VP_PHRASES = [
  { key: "voice_guide_on",  label: "Voice guide is on",        sample: "Voice guide is on. You are now on the page." },
  { key: "voice_guide_off", label: "Voice guide is off",       sample: "Voice guide is off." },
  { key: "reading_now",     label: "Reading now",              sample: "Reading now." },
  { key: "done_reading",    label: "Done reading",             sample: "Done reading." },
  { key: "scrolling_down",  label: "Scrolling down",           sample: "Scrolling down." },
  { key: "scrolling_up",    label: "Scrolling up",             sample: "Scrolling up." },
  { key: "listening",       label: "Listening (voice cmd)",    sample: "Listening. Say a command." },
  { key: "smart_reader_on",  label: "Smart reading is on",      sample: "Smart reading is on." },
  { key: "smart_reader_off", label: "Smart reading is off",     sample: "Smart reading is off." },
];

const form = {
  contrast:          document.getElementById("contrast"),
  spacing:           document.getElementById("spacing"),
  focusMode:         document.getElementById("focusMode"),
  screenReader:      document.getElementById("screenReader"),
  voiceCommand:      document.getElementById("voiceCommand"),
  smartReader:       document.getElementById("smartReader"),
  textScale:         document.getElementById("textScale"),
  textScaleValue:    document.getElementById("textScaleValue"),
  voiceURI:          document.getElementById("voiceURI"),
  speechRate:        document.getElementById("speechRate"),
  speechRateValue:   document.getElementById("speechRateValue"),
  speechPitch:       document.getElementById("speechPitch"),
  speechPitchValue:  document.getElementById("speechPitchValue"),
  hoverDelay:        document.getElementById("hoverDelay"),
  hoverDelayValue:   document.getElementById("hoverDelayValue"),
  highlightColor:    document.getElementById("highlightColor"),
  highlightColorLabel: document.getElementById("highlightColorLabel"),
  save:              document.getElementById("save"),
  restore:           document.getElementById("restore"),
  status:            document.getElementById("status"),
  vpList:            document.getElementById("vp-list"),
  vpStatus:          document.getElementById("vp-status"),
  aiEnabled:         document.getElementById("aiEnabled"),
  aiProviderOpenai:  document.getElementById("aiProviderOpenai"),
  aiProviderOllama:  document.getElementById("aiProviderOllama"),
  aiOpenaiFields:    document.getElementById("aiOpenaiFields"),
  aiOllamaFields:    document.getElementById("aiOllamaFields"),
  aiApiKey:          document.getElementById("aiApiKey"),
  aiOllamaUrl:       document.getElementById("aiOllamaUrl"),
  aiOllamaModel:     document.getElementById("aiOllamaModel"),
};

let voiceProfile = {};      // phraseKey → base64 audio
let activeRecorders = {};   // phraseKey → MediaRecorder

// ═══════════════════════════════════════════════════════════════
// STORAGE
// ═══════════════════════════════════════════════════════════════

function clamp(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); }

function storageGetState() {
  return new Promise(resolve =>
    chrome.storage.local.get({ [STATE_KEY]: DEFAULT_STATE }, items =>
      resolve({ ...DEFAULT_STATE, ...(items[STATE_KEY] || {}) })));
}

function storageSetState(s) {
  return new Promise(resolve => chrome.storage.local.set({ [STATE_KEY]: s }, resolve));
}

function storageGetVP() {
  return new Promise(resolve =>
    chrome.storage.local.get({ [VP_KEY]: {} }, items => resolve(items[VP_KEY] || {})));
}

function storageSetVP(vp) {
  return new Promise(resolve => chrome.storage.local.set({ [VP_KEY]: vp }, resolve));
}

function storageGetAiConfig() {
  return new Promise(resolve =>
    chrome.storage.local.get({ [AI_KEY]: DEFAULT_AI_CONFIG }, items =>
      resolve({ ...DEFAULT_AI_CONFIG, ...(items[AI_KEY] || {}) })));
}

function storageSetAiConfig(cfg) {
  return new Promise(resolve => chrome.storage.local.set({ [AI_KEY]: cfg }, resolve));
}

function setStatus(msg) { form.status.textContent = msg; }
function setVpStatus(msg) { form.vpStatus.textContent = msg; }

// ═══════════════════════════════════════════════════════════════
// FORM ↔ STATE
// ═══════════════════════════════════════════════════════════════

function getFormState() {
  return {
    contrast:       form.contrast.checked,
    textScale:      Number(clamp(Number(form.textScale.value), 0.8, 2.0).toFixed(2)),
    spacing:        form.spacing.checked,
    focusMode:      form.focusMode.checked,
    screenReader:   form.screenReader.checked,
    voiceCommand:   form.voiceCommand.checked,
    smartReader:    form.smartReader.checked,
    speechRate:     Number(clamp(Number(form.speechRate.value), 0.5, 2).toFixed(1)),
    speechPitch:    Number(clamp(Number(form.speechPitch.value), 0, 2).toFixed(1)),
    voiceURI:       form.voiceURI.value,
    hoverDelay:     Number(clamp(Number(form.hoverDelay.value), 100, 2000)),
    highlightColor: form.highlightColor.value || "#f59e0b"
  };
}

function applyStateToForm(s) {
  form.contrast.checked      = Boolean(s.contrast);
  form.spacing.checked       = Boolean(s.spacing);
  form.focusMode.checked     = Boolean(s.focusMode);
  form.screenReader.checked  = Boolean(s.screenReader);
  form.voiceCommand.checked  = Boolean(s.voiceCommand);
  form.smartReader.checked   = Boolean(s.smartReader);
  form.textScale.value       = String(clamp(Number(s.textScale) || 1, 0.8, 2.0));
  form.speechRate.value      = String(clamp(Number(s.speechRate) || 1, 0.5, 2));
  form.speechPitch.value     = String(clamp(Number(s.speechPitch) || 1, 0, 2));
  form.hoverDelay.value      = String(clamp(Number(s.hoverDelay) || 500, 100, 2000));
  form.highlightColor.value  = typeof s.highlightColor === "string" ? s.highlightColor : "#f59e0b";
  form.voiceURI.value        = typeof s.voiceURI === "string" ? s.voiceURI : "";
  updateLabels();
}

function updateLabels() {
  form.textScaleValue.textContent    = `${Math.round(Number(form.textScale.value) * 100)}%`;
  form.speechRateValue.textContent   = `${Number(form.speechRate.value).toFixed(1)}×`;
  form.speechPitchValue.textContent  = `${Number(form.speechPitch.value).toFixed(1)}×`;
  form.hoverDelayValue.textContent   = `${form.hoverDelay.value}ms`;
  form.highlightColorLabel.textContent = form.highlightColor.value;
}

// ═══════════════════════════════════════════════════════════════
// VOICE LIST
// ═══════════════════════════════════════════════════════════════

function escapeHtml(v) {
  return String(v).replace(/&/g,"&amp;").replace(/</g,"&lt;")
    .replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}

async function loadVoices(selectedURI) {
  const voices = "speechSynthesis" in window ? (window.speechSynthesis.getVoices?.() || []) : [];
  form.voiceURI.innerHTML = [
    '<option value="">System default</option>',
    ...voices.map(v => `<option value="${escapeHtml(v.voiceURI)}">${escapeHtml(v.name)} (${v.lang || "?"})</option>`)
  ].join("");
  if (selectedURI) form.voiceURI.value = selectedURI;
}

// ═══════════════════════════════════════════════════════════════
// VOICE PROFILE — recording UI
// ═══════════════════════════════════════════════════════════════

function renderVoiceProfile() {
  if (!form.vpList) return;
  form.vpList.innerHTML = "";

  for (const phrase of VP_PHRASES) {
    const hasRecording = Boolean(voiceProfile[phrase.key]);
    const row = document.createElement("div");
    row.className = "vp-row";
    row.dataset.key = phrase.key;

    row.innerHTML = `
      <div class="vp-label">
        <span class="vp-phrase">${escapeHtml(phrase.label)}</span>
        <span class="vp-sample">"${escapeHtml(phrase.sample)}"</span>
      </div>
      <div class="vp-controls">
        ${hasRecording
          ? `<span class="vp-badge">✓ Recorded</span>
             <button class="vp-btn vp-play"  data-key="${phrase.key}" title="Play back your recording">▶ Play</button>
             <button class="vp-btn vp-delete" data-key="${phrase.key}" title="Delete this recording">✕ Delete</button>`
          : `<button class="vp-btn vp-record" data-key="${phrase.key}" title="Record this phrase">🎤 Record</button>`
        }
      </div>
    `;
    form.vpList.appendChild(row);
  }

  // Wire up buttons
  form.vpList.querySelectorAll(".vp-record").forEach(btn => {
    btn.addEventListener("click", () => startRecording(btn.dataset.key));
  });
  form.vpList.querySelectorAll(".vp-play").forEach(btn => {
    btn.addEventListener("click", () => playRecording(btn.dataset.key));
  });
  form.vpList.querySelectorAll(".vp-delete").forEach(btn => {
    btn.addEventListener("click", () => deleteRecording(btn.dataset.key));
  });
}

async function startRecording(phraseKey) {
  if (activeRecorders[phraseKey]) return; // already recording

  let stream;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  } catch (err) {
    setVpStatus("Microphone access was denied. Please allow microphone access in your browser and try again.");
    return;
  }

  const phrase = VP_PHRASES.find(p => p.key === phraseKey);
  setVpStatus(`Recording… say: "${phrase?.sample || phrase?.label}"`);

  const chunks = [];
  const recorder = new MediaRecorder(stream, { mimeType: "audio/webm" });
  activeRecorders[phraseKey] = recorder;

  // Update button to "Stop recording"
  const row = form.vpList.querySelector(`[data-key="${phraseKey}"]`);
  const recBtn = row?.querySelector(".vp-record");
  if (recBtn) {
    recBtn.textContent = "⏹ Stop";
    recBtn.classList.add("vp-recording");
    recBtn.removeEventListener("click", () => startRecording(phraseKey));
    recBtn.addEventListener("click", () => stopRecording(phraseKey, stream), { once: true });
  }

  recorder.ondataavailable = e => { if (e.data.size > 0) chunks.push(e.data); };
  recorder.onstop = async () => {
    const blob  = new Blob(chunks, { type: "audio/webm" });
    const b64   = await blobToBase64(blob);
    voiceProfile[phraseKey] = b64;
    await storageSetVP(voiceProfile);
    stream.getTracks().forEach(t => t.stop());
    delete activeRecorders[phraseKey];
    setVpStatus(`✓ Recorded "${phrase?.label}". Your voice will now be used for this phrase.`);
    renderVoiceProfile();
  };

  recorder.start();
}

function stopRecording(phraseKey, stream) {
  const rec = activeRecorders[phraseKey];
  if (rec && rec.state === "recording") rec.stop();
}

function playRecording(phraseKey) {
  const b64 = voiceProfile[phraseKey];
  if (!b64) return;
  try {
    const binary = atob(b64);
    const bytes  = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    const blob  = new Blob([bytes], { type: "audio/webm" });
    const url   = URL.createObjectURL(blob);
    const audio = new Audio(url);
    audio.onended = () => URL.revokeObjectURL(url);
    audio.play();
    setVpStatus("Playing your recording…");
  } catch (err) {
    setVpStatus("Could not play the recording. Please re-record.");
  }
}

async function deleteRecording(phraseKey) {
  delete voiceProfile[phraseKey];
  await storageSetVP(voiceProfile);
  const phrase = VP_PHRASES.find(p => p.key === phraseKey);
  setVpStatus(`Deleted recording for "${phrase?.label}". The system voice will be used instead.`);
  renderVoiceProfile();
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload  = () => {
      const dataUrl = reader.result;
      // Strip the "data:audio/webm;base64," prefix
      const b64 = dataUrl.split(",")[1];
      resolve(b64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

// ═══════════════════════════════════════════════════════════════
// SAVE / RESTORE
// ═══════════════════════════════════════════════════════════════

function getAiProvider() {
  return form.aiProviderOllama.checked ? "ollama" : "openai";
}

function updateAiProviderFields() {
  const provider = getAiProvider();
  form.aiOpenaiFields.hidden = provider !== "openai";
  form.aiOllamaFields.hidden = provider !== "ollama";
}

async function save() {
  await storageSetState(getFormState());
  await storageSetAiConfig({
    enabled: form.aiEnabled.checked,
    provider: getAiProvider(),
    apiKey: form.aiApiKey.value.trim(),
    openaiModel: DEFAULT_AI_CONFIG.openaiModel,
    ollamaUrl: form.aiOllamaUrl.value.trim() || DEFAULT_AI_CONFIG.ollamaUrl,
    ollamaModel: form.aiOllamaModel.value.trim() || DEFAULT_AI_CONFIG.ollamaModel
  });
  setStatus("✓ Your settings have been saved.");
}

async function restoreDefaults() {
  applyStateToForm(DEFAULT_STATE);
  await storageSetState(DEFAULT_STATE);
  setStatus("Settings have been reset to defaults.");
}

// ═══════════════════════════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════════════════════════

async function init() {
  const [savedState, savedVP, savedAi] = await Promise.all([storageGetState(), storageGetVP(), storageGetAiConfig()]);
  voiceProfile = savedVP;
  applyStateToForm(savedState);
  form.aiEnabled.checked = Boolean(savedAi.enabled);
  const provider = savedAi.provider === "ollama" ? "ollama" : "openai";
  form.aiProviderOpenai.checked = provider === "openai";
  form.aiProviderOllama.checked = provider === "ollama";
  form.aiApiKey.value = typeof savedAi.apiKey === "string" ? savedAi.apiKey : "";
  form.aiOllamaUrl.value = typeof savedAi.ollamaUrl === "string" && savedAi.ollamaUrl ? savedAi.ollamaUrl : DEFAULT_AI_CONFIG.ollamaUrl;
  form.aiOllamaModel.value = typeof savedAi.ollamaModel === "string" && savedAi.ollamaModel ? savedAi.ollamaModel : DEFAULT_AI_CONFIG.ollamaModel;
  updateAiProviderFields();
  form.aiProviderOpenai.addEventListener("change", updateAiProviderFields);
  form.aiProviderOllama.addEventListener("change", updateAiProviderFields);
  await loadVoices(savedState.voiceURI);
  renderVoiceProfile();

  // Form input listeners
  ["contrast","spacing","focusMode","screenReader","voiceCommand","smartReader"].forEach(id => {
    form[id]?.addEventListener("change", updateLabels);
  });
  ["textScale","speechRate","speechPitch","hoverDelay"].forEach(id => {
    form[id]?.addEventListener("input", updateLabels);
  });
  form.highlightColor?.addEventListener("input", updateLabels);

  form.save.addEventListener("click", save);
  form.restore.addEventListener("click", restoreDefaults);

  if ("speechSynthesis" in window) {
    window.speechSynthesis.onvoiceschanged = () => loadVoices(form.voiceURI.value);
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes[STATE_KEY])
      applyStateToForm({ ...DEFAULT_STATE, ...(changes[STATE_KEY].newValue || {}) });
    if (changes[VP_KEY]) {
      voiceProfile = changes[VP_KEY].newValue || {};
      renderVoiceProfile();
    }
  });
}

init();
