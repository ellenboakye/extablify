(() => {
  const STATE_KEY = "extabilifyState";
  const STYLE_ID  = "extabilify-style";
  const TOAST_ID  = "extabilify-toast";
  const ANNOUNCER_ID = "extabilify-announcer";
  const MIC_INDICATOR_ID = "extabilify-mic";

  const DEFAULT_STATE = {
    contrast:    false,
    textScale:   1,
    spacing:     false,
    focusMode:   false,
    screenReader: false,
    speechRate:  1,
    speechPitch: 1,
    voiceURI:    "",
    voiceCommand: true,    // Always-on voice-command navigation for hands-free access
    hoverDelay:  500,      // NEW — configurable for students with tremors
    highlightColor: "#f59e0b", // NEW — configurable hover highlight
    smartReader: false     // NEW (v0.3) — intelligent DOM annotation + quiz mode
  };

  let currentState    = normalizeState(DEFAULT_STATE);
  let hasAppliedState = false;
  let toastTimer      = null;
  let selectionTimer  = null;
  let speakTimer      = null;
  let speechToken     = 0;
  let isUserSpeaking  = false;
  let availableVoices = [];
  let lastSelection   = {
    text: "", lang: document.documentElement.lang || navigator.language || "en-US",
    url: location.href, updatedAt: 0
  };

  // ── Screen-reader state ────────────────────────────────────────────────────
  let narrateToken      = 0;
  let lastNarratedElement = null;
  let hoverTimer        = null;
  let scrollNarrationTimer = null;
  let lastScrollY       = 0;

  // ── Voice-command state ────────────────────────────────────────────────────
  let vcRecognition     = null;
  let vcListening       = false;
  let vcLoop            = false;   // keep the mic on continuously — general commands and quiz mode both use this
  let vcRestartTimer    = null;
  let vcManuallyPaused  = false;
  let lastVoiceCommandPlan = null;
  // Counts attempts since the last real result. Some browsers (especially on
  // file:// pages, where mic permission rarely persists) fire a "soft" error
  // like "aborted" instead of "not-allowed" when the permission prompt can't
  // be satisfied — without a cap, the always-on loop would retry forever and
  // re-trigger the permission prompt every time, nagging indefinitely.
  let vcConsecutiveFails = 0;
  const VC_MAX_CONSECUTIVE_FAILS = 6;

  // ── Voice-profile state (pre-recorded user phrases) ───────────────────────
  const VP_KEY = "extabilifyVoiceProfile";
  let voiceProfileMap   = {};   // phraseKey → base64 audio string

  // ── Smart-reader / quiz-mode state (v0.3) ─────────────────────────────────
  let smartObserver     = null;
  let smartScanTimer    = null;
  const EXAM = {
    active: false,
    questions: [],   // [{ id, name, container, stem, options:[{letter,label,input}] }]
    index: -1,
    submitArmed: false,
    // True for exactly one navigation command right after a single-choice
    // answer auto-advances to the next question — guards against a reflexive
    // "next" silently skipping the question the student never actually heard.
    autoAdvancePending: false
  };

  // Voice commands increment this on every fresh recognized utterance; async
  // work (AI refinement) captures it and discards its result if a newer
  // utterance has since started, so a slow network reply can never fire late.
  let voiceCommandGen = 0;

  // ═══════════════════════════════════════════════════════════════
  // UTILITIES
  // ═══════════════════════════════════════════════════════════════

  function clamp(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); }

  function normalizeState(input) {
    const n = { ...DEFAULT_STATE, ...(input || {}) };
    return {
      contrast:      Boolean(n.contrast),
      textScale:     clamp(Number(n.textScale) || 1, 0.8, 2.0),
      spacing:       Boolean(n.spacing),
      focusMode:     Boolean(n.focusMode),
      screenReader:  Boolean(n.screenReader),
      speechRate:    clamp(Number(n.speechRate) || 1, 0.5, 2),
      speechPitch:   clamp(Number(n.speechPitch) || 1, 0, 2),
      voiceURI:      typeof n.voiceURI === "string" ? n.voiceURI : "",
      voiceCommand:  Boolean(n.voiceCommand),
      hoverDelay:    clamp(Number(n.hoverDelay) || 500, 100, 2000),
      highlightColor: typeof n.highlightColor === "string" ? n.highlightColor : "#f59e0b",
      smartReader:   Boolean(n.smartReader)
    };
  }

  // ═══════════════════════════════════════════════════════════════
  // STYLES
  // ═══════════════════════════════════════════════════════════════

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      html {
        --extabilify-font-scale: 1;
        --extabilify-line-height: 1.55;
        --extabilify-letter-spacing: 0em;
        --extabilify-word-spacing: 0em;
        --extabilify-surface: #ffffff;
        --extabilify-ink: #0f172a;
        --extabilify-link: #0f62fe;
        --extabilify-highlight: #f59e0b;
      }
      html[data-extabilify-contrast="true"] {
        color-scheme: dark;
        --extabilify-surface: #0b1020;
        --extabilify-ink: #f8fafc;
        --extabilify-link: #7dd3fc;
      }
      html[data-extabilify-text-scale="true"] {
        font-size: calc(100% * var(--extabilify-font-scale)) !important;
      }
      html[data-extabilify-spacing="true"] body {
        line-height: var(--extabilify-line-height) !important;
        letter-spacing: var(--extabilify-letter-spacing) !important;
        word-spacing: var(--extabilify-word-spacing) !important;
      }
      html[data-extabilify-contrast="true"] body {
        background: var(--extabilify-surface) !important;
        color: var(--extabilify-ink) !important;
      }
      html[data-extabilify-contrast="true"] main,
      html[data-extabilify-contrast="true"] article,
      html[data-extabilify-contrast="true"] section {
        background-color: transparent !important; color: inherit !important;
      }
      html[data-extabilify-contrast="true"] a {
        color: var(--extabilify-link) !important;
        text-decoration-thickness: 0.14em !important;
        text-underline-offset: 0.12em !important;
      }
      html[data-extabilify-contrast="true"] input,
      html[data-extabilify-contrast="true"] textarea,
      html[data-extabilify-contrast="true"] select,
      html[data-extabilify-contrast="true"] button {
        background-color: #0f172a !important;
        color: #f8fafc !important;
        border-color: #94a3b8 !important;
      }
      html[data-extabilify-contrast="true"] ::selection {
        background: #fbbf24 !important; color: #0f172a !important;
      }
      html[data-extabilify-focus-mode="true"] body { overflow-x: hidden !important; }
      html[data-extabilify-focus-mode="true"] header,
      html[data-extabilify-focus-mode="true"] nav,
      html[data-extabilify-focus-mode="true"] aside,
      html[data-extabilify-focus-mode="true"] footer,
      html[data-extabilify-focus-mode="true"] [role="banner"],
      html[data-extabilify-focus-mode="true"] [role="navigation"],
      html[data-extabilify-focus-mode="true"] [role="complementary"],
      html[data-extabilify-focus-mode="true"] [aria-label*="advert" i],
      html[data-extabilify-focus-mode="true"] [class*="advert" i],
      html[data-extabilify-focus-mode="true"] [id*="advert" i],
      html[data-extabilify-focus-mode="true"] [class*="promo" i],
      html[data-extabilify-focus-mode="true"] [class*="cookie" i],
      html[data-extabilify-focus-mode="true"] [id*="cookie" i],
      html[data-extabilify-focus-mode="true"] [class*="sidebar" i],
      html[data-extabilify-focus-mode="true"] [class*="share" i] {
        display: none !important; visibility: hidden !important;
      }
      html[data-extabilify-focus-mode="true"] main,
      html[data-extabilify-focus-mode="true"] article,
      html[data-extabilify-focus-mode="true"] [role="main"] {
        max-width: 72ch !important;
        margin-inline: auto !important;
        padding-inline: 1rem !important;
      }
      html[data-extabilify-focus-mode="true"] img,
      html[data-extabilify-focus-mode="true"] video,
      html[data-extabilify-focus-mode="true"] canvas,
      html[data-extabilify-focus-mode="true"] svg { max-width: 100% !important; }

      /* Screen-reader hover outline — colour from CSS variable */
      html[data-extabilify-screen-reader="true"] [data-extabilify-hovered] {
        outline: 3px solid var(--extabilify-highlight) !important;
        outline-offset: 2px !important;
      }

      /* Smart-reader: currently-read quiz question */
      html[data-extabilify-smart-reader="true"] [data-extabilify-exam-current="true"] {
        outline: 3px solid var(--extabilify-highlight) !important;
        outline-offset: 4px !important;
        border-radius: 4px;
        scroll-margin: 25vh;
      }
      html[data-extabilify-smart-reader="true"] [data-extabilify-exam-answered="true"] {
        box-shadow: inset 4px 0 0 0 #16a34a !important;
      }

      /* Found-text highlight */
      [data-extabilify-found] {
        background: rgba(245,158,11,0.35) !important;
        outline: 2px solid #f59e0b !important;
        border-radius: 2px;
      }

      /* Toast */
      #${TOAST_ID} {
        position: fixed; inset-inline-end: 1rem; inset-block-end: 1rem;
        z-index: 2147483647; max-width: min(24rem, calc(100vw - 2rem));
        padding: 0.9rem 1rem; border-radius: 1rem;
        background: rgba(15,23,42,0.96); color: #f8fafc;
        font-family: "Trebuchet MS","Verdana",sans-serif; font-size: 0.92rem;
        line-height: 1.4; box-shadow: 0 20px 45px rgba(15,23,42,0.35);
        transform: translateY(120%); opacity: 0;
        transition: transform 180ms ease, opacity 180ms ease;
        pointer-events: none;
      }
      #${TOAST_ID}[data-visible="true"] { transform: translateY(0); opacity: 1; }

      /* Mic listening indicator */
      #${MIC_INDICATOR_ID} {
        position: fixed; inset-inline-start: 50%; top: 1rem;
        transform: translateX(-50%) translateY(-200%);
        z-index: 2147483647;
        background: #dc2626; color: #fff;
        padding: 0.5rem 1.2rem; border-radius: 2rem;
        font-family: "Trebuchet MS","Verdana",sans-serif; font-size: 0.9rem;
        font-weight: 700; letter-spacing: 0.04em;
        box-shadow: 0 4px 20px rgba(220,38,38,0.4);
        transition: transform 200ms ease, opacity 200ms ease;
        opacity: 0; pointer-events: none;
      }
      #${MIC_INDICATOR_ID}[data-visible="true"] {
        transform: translateX(-50%) translateY(0);
        opacity: 1;
      }
      #${MIC_INDICATOR_ID}::before { content: "🎤 "; }

      /* Announcer (screen-reader only) */
      #${ANNOUNCER_ID} {
        position: absolute; width: 1px; height: 1px;
        overflow: hidden; clip: rect(0 0 0 0);
        white-space: nowrap; clip-path: inset(50%);
      }
    `;
    document.documentElement.appendChild(style);
  }

  // ═══════════════════════════════════════════════════════════════
  // TOAST & ANNOUNCER
  // ═══════════════════════════════════════════════════════════════

  function ensureToast() {
    let t = document.getElementById(TOAST_ID);
    if (!t) {
      t = document.createElement("div"); t.id = TOAST_ID;
      t.setAttribute("role","status"); t.setAttribute("aria-live","polite");
      document.documentElement.appendChild(t);
    }
    return t;
  }

  function ensureAnnouncer() {
    let a = document.getElementById(ANNOUNCER_ID);
    if (!a) {
      a = document.createElement("div"); a.id = ANNOUNCER_ID;
      a.setAttribute("role","status"); a.setAttribute("aria-live","polite");
      document.documentElement.appendChild(a);
    }
    return a;
  }

  function ensureMicIndicator() {
    let m = document.getElementById(MIC_INDICATOR_ID);
    if (!m) {
      m = document.createElement("div"); m.id = MIC_INDICATOR_ID;
      m.setAttribute("aria-live","assertive"); m.setAttribute("role","status");
      document.documentElement.appendChild(m);
    }
    return m;
  }

  function announce(msg) {
    const a = ensureAnnouncer();
    a.textContent = "";
    window.setTimeout(() => { a.textContent = msg; }, 25);
  }

  function showToast(msg, duration = 2400) {
    const t = ensureToast();
    t.textContent = msg; t.dataset.visible = "true";
    announce(msg);
    if (toastTimer) window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => { t.dataset.visible = "false"; }, duration);
  }

  // ═══════════════════════════════════════════════════════════════
  // STATE SYNC
  // ═══════════════════════════════════════════════════════════════

  function syncStateToDocument() {
    const r = document.documentElement;
    r.toggleAttribute("data-extabilify-contrast",     currentState.contrast);
    r.toggleAttribute("data-extabilify-text-scale",   currentState.textScale !== 1);
    r.toggleAttribute("data-extabilify-spacing",      currentState.spacing);
    r.toggleAttribute("data-extabilify-focus-mode",   currentState.focusMode);
    r.toggleAttribute("data-extabilify-screen-reader",currentState.screenReader);
    r.toggleAttribute("data-extabilify-smart-reader", currentState.smartReader);
    r.style.setProperty("--extabilify-font-scale",      String(currentState.textScale));
    r.style.setProperty("--extabilify-line-height",     currentState.spacing ? "1.75" : "1.55");
    r.style.setProperty("--extabilify-letter-spacing",  currentState.spacing ? "0.02em" : "0em");
    r.style.setProperty("--extabilify-word-spacing",    currentState.spacing ? "0.08em" : "0em");
    r.style.setProperty("--extabilify-highlight",       currentState.highlightColor);
  }

  function applyState(nextState) {
    const prevSR    = currentState.screenReader;
    const prevVC    = currentState.voiceCommand;
    const prevSmart = currentState.smartReader;
    const firstApply = !hasAppliedState;
    currentState    = normalizeState(nextState);
    hasAppliedState = true;
    syncStateToDocument();

    if (firstApply ? currentState.screenReader : currentState.screenReader !== prevSR) {
      if (currentState.screenReader) installScreenReaderListeners();
      else if (!firstApply) uninstallScreenReaderListeners();
    }
    if (firstApply ? currentState.voiceCommand : currentState.voiceCommand !== prevVC) {
      if (currentState.voiceCommand) installVoiceCommand();
      else if (!firstApply) uninstallVoiceCommand();
    }
    if (firstApply ? currentState.smartReader : currentState.smartReader !== prevSmart) {
      if (currentState.smartReader) installSmartReader();
      else if (!firstApply) uninstallSmartReader();
    }
  }

  function toggleStateKey(key) {
    chrome.storage.local.get({ [STATE_KEY]: DEFAULT_STATE }, items => {
      const s = normalizeState(items[STATE_KEY]);
      s[key] = !s[key];
      chrome.storage.local.set({ [STATE_KEY]: s });
    });
  }

  // ═══════════════════════════════════════════════════════════════
  // LANGUAGE & VOICES
  // ═══════════════════════════════════════════════════════════════

  function getPageLanguage() {
    return document.documentElement.lang || navigator.language || "en-US";
  }

  function refreshVoices() {
    if (!("speechSynthesis" in window)) { availableVoices = []; return; }
    availableVoices = window.speechSynthesis.getVoices?.() || [];
  }

  function getPreferredVoice() {
    if (!currentState.voiceURI) return null;
    if (!availableVoices.length) refreshVoices();
    return availableVoices.find(v => v.voiceURI === currentState.voiceURI) || null;
  }

  // ═══════════════════════════════════════════════════════════════
  // VOICE PROFILE — play back user's own recorded confirmation
  // ═══════════════════════════════════════════════════════════════

  function loadVoiceProfile() {
    chrome.storage.local.get({ [VP_KEY]: {} }, items => {
      voiceProfileMap = items[VP_KEY] || {};
    });
  }

  /**
   * If the user recorded their own voice for this phraseKey,
   * play that recording. Otherwise fall back to TTS narration.
   * @param {string} phraseKey  e.g. "voice_guide_on"
   * @param {string} fallback   e.g. "Voice guide is on"
   */
  function speakWithProfile(phraseKey, fallback) {
    const b64 = voiceProfileMap[phraseKey];
    if (b64) {
      try {
        const binary  = atob(b64);
        const bytes   = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
        const blob    = new Blob([bytes], { type: "audio/webm" });
        const url     = URL.createObjectURL(blob);
        const audio   = new Audio(url);
        audio.onended = () => URL.revokeObjectURL(url);
        audio.play().catch(() => speakNarration(fallback));
        announce(fallback);
        return;
      } catch (_) { /* fall through */ }
    }
    speakNarration(fallback);
  }

  // ═══════════════════════════════════════════════════════════════
  // SELECTION TRACKING
  // ═══════════════════════════════════════════════════════════════

  function getSelectionText() {
    const ae = document.activeElement;
    if (ae instanceof HTMLInputElement) {
      const tt = /^(text|search|url|tel|email|password)$/i;
      if (tt.test(ae.type)) {
        const { selectionStart: s, selectionEnd: e } = ae;
        if (typeof s === "number" && typeof e === "number" && e > s)
          return ae.value.slice(s, e).replace(/\s+/g," ").trim();
      }
    }
    if (ae instanceof HTMLTextAreaElement) {
      const { selectionStart: s, selectionEnd: e } = ae;
      if (typeof s === "number" && typeof e === "number" && e > s)
        return ae.value.slice(s, e).replace(/\s+/g," ").trim();
    }
    return (window.getSelection?.()?.toString() || "").replace(/\s+/g," ").trim();
  }

  function syncSelectionCache() {
    const text = getSelectionText();
    if (text) {
      lastSelection = { text, lang: getPageLanguage(), url: location.href, updatedAt: Date.now() };
    } else if (!lastSelection.text) {
      lastSelection = { text: "", lang: getPageLanguage(), url: location.href, updatedAt: Date.now() };
    }
  }

  function scheduleSelectionSync() {
    if (selectionTimer) window.clearTimeout(selectionTimer);
    selectionTimer = window.setTimeout(syncSelectionCache, 0);
  }

  function installSelectionObservers() {
    document.addEventListener("selectionchange", scheduleSelectionSync, true);
    document.addEventListener("mouseup",         scheduleSelectionSync, true);
    document.addEventListener("keyup",           scheduleSelectionSync, true);
    document.addEventListener("touchend",        scheduleSelectionSync, true);
  }

  // ═══════════════════════════════════════════════════════════════
  // USER-INITIATED TTS
  // ═══════════════════════════════════════════════════════════════

  function speakSelectionText(text, lang) {
    if (!("speechSynthesis" in window) || typeof SpeechSynthesisUtterance === "undefined") {
      showToast("Sorry, your browser cannot read text aloud.");
      return false;
    }
    const trimmed = String(text || "").replace(/\s+/g," ").trim();
    if (!trimmed) { showToast("Please highlight some text on the page first."); return false; }

    const reqId = ++speechToken;
    narrateToken++;
    isUserSpeaking = true;

    const utter  = new SpeechSynthesisUtterance(trimmed);
    const voice  = getPreferredVoice();
    if (speakTimer) { window.clearTimeout(speakTimer); speakTimer = null; }
    window.speechSynthesis.cancel();

    utter.lang  = lang || getPageLanguage();
    utter.rate  = currentState.speechRate;
    utter.pitch = currentState.speechPitch;
    if (voice) utter.voice = voice;

    utter.onstart = () => { if (reqId === speechToken) showToast("Reading now..."); };

    speakTimer = window.setTimeout(() => {
      if (reqId !== speechToken) { isUserSpeaking = false; return; }
      window.speechSynthesis.speak(utter);

      const rv = window.setInterval(() => {
        if (!window.speechSynthesis.speaking || reqId !== speechToken) {
          window.clearInterval(rv); return;
        }
        if (window.speechSynthesis.paused) window.speechSynthesis.resume();
      }, 250);

      utter.onend = () => {
        window.clearInterval(rv);
        isUserSpeaking = false;
        if (reqId === speechToken) showToast("Done reading.");
      };
      utter.onerror = () => {
        window.clearInterval(rv);
        isUserSpeaking = false;
        if (reqId === speechToken) showToast("Could not read that. Please try again.");
      };
    }, 75);

    return true;
  }

  // ═══════════════════════════════════════════════════════════════
  // SCREEN-READER — element description helpers
  // ═══════════════════════════════════════════════════════════════

  function getAriaLabelledByText(el) {
    const ids = (el.getAttribute("aria-labelledby") || "").trim();
    if (!ids) return "";
    return ids.split(/\s+/).map(id => document.getElementById(id)?.textContent?.replace(/\s+/g," ").trim() || "").filter(Boolean).join(" ");
  }

  function getAriaDescribedByText(el) {
    const ids = (el.getAttribute("aria-describedby") || "").trim();
    if (!ids) return "";
    return ids.split(/\s+/).map(id => document.getElementById(id)?.textContent?.replace(/\s+/g," ").trim() || "").filter(Boolean).join(". ");
  }

  function getLabelText(el) {
    if (el.id) {
      try {
        const explicit = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
        if (explicit) return explicit.textContent.replace(/\s+/g," ").trim();
      } catch(_) {}
    }
    const wrapped = el.closest("label");
    if (wrapped) {
      const clone = wrapped.cloneNode(true);
      clone.querySelectorAll("input,select,textarea,button").forEach(n => n.remove());
      return clone.textContent.replace(/\s+/g," ").trim();
    }
    return "";
  }

  function getElementRole(el) {
    const explicit = (el.getAttribute("role") || "").trim();
    if (explicit) return explicit;
    const tag  = el.tagName.toLowerCase();
    const type = (el instanceof HTMLInputElement ? el.type || "text" : "").toLowerCase();
    if (tag === "input") {
      return ({ text:"text field", email:"email field", password:"password field",
                search:"search field", tel:"phone field", url:"URL field",
                number:"number field", checkbox:"checkbox", radio:"radio button",
                submit:"submit button", reset:"reset button", button:"button",
                file:"file upload", range:"slider", date:"date picker",
                time:"time picker", color:"color picker" }[type] || "input field");
    }
    return ({ a:"link", button:"button", select:"dropdown list", textarea:"text area",
              h1:"heading 1", h2:"heading 2", h3:"heading 3", h4:"heading 4",
              h5:"heading 5", h6:"heading 6", img:"image", nav:"navigation region",
              main:"main content", form:"form", table:"table", dialog:"dialog",
              details:"expandable section", summary:"summary",
              figure:"figure", figcaption:"figure caption" }[tag] || "");
  }

  function describeElement(el) {
    if (!el || el === document.body || el === document.documentElement) return "";
    if (el.closest(`#${TOAST_ID},#${ANNOUNCER_ID},#${MIC_INDICATOR_ID}`)) return "";

    const INTERACTIVE = [
      "a[href]","button","input:not([type=hidden])","select","textarea",
      "[role=button]","[role=link]","[role=checkbox]","[role=radio]",
      "[role=menuitem]","[role=tab]","[role=combobox]","[role=textbox]",
      "[role=spinbutton]","[role=slider]","[role=switch]",
      "label","h1","h2","h3","h4","h5","h6",
      "img[alt]","details","dialog","summary",
      "[aria-label]","[aria-labelledby]","[title]",
      "[tabindex]:not([tabindex='-1'])"
    ].join(",");

    const target = el.closest(INTERACTIVE) || el;
    if (target.closest(`#${TOAST_ID},#${ANNOUNCER_ID},#${MIC_INDICATOR_ID}`)) return "";

    const rawName = (
      target.getAttribute("aria-label") ||
      getAriaLabelledByText(target)      ||
      getLabelText(target)               ||
      ((target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement)
        ? target.placeholder || "" : "")  ||
      target.getAttribute("alt")         ||
      target.getAttribute("title")       ||
      (target.innerText || target.textContent || "").replace(/\s+/g," ").trim().slice(0,100)
    ).trim();

    const role   = getElementRole(target);
    const parts  = [];
    if (rawName) parts.push(rawName);
    if (role)    parts.push(role);

    const states = [];
    const required = target.getAttribute("aria-required") === "true" ||
                     (target instanceof HTMLInputElement  && target.required) ||
                     (target instanceof HTMLTextAreaElement && target.required) ||
                     (target instanceof HTMLSelectElement && target.required);
    if (required) states.push("required");

    const disabled = (target instanceof HTMLButtonElement  && target.disabled) ||
                     (target instanceof HTMLInputElement   && target.disabled) ||
                     (target instanceof HTMLSelectElement  && target.disabled) ||
                     (target instanceof HTMLTextAreaElement && target.disabled) ||
                     target.getAttribute("aria-disabled") === "true";
    if (disabled) states.push("disabled");

    const expanded = target.getAttribute("aria-expanded");
    if (expanded === "true")  states.push("expanded");
    if (expanded === "false") states.push("collapsed");

    if (target instanceof HTMLInputElement) {
      if (target.type === "checkbox" || target.type === "radio")
        states.push(target.checked ? "checked" : "not checked");
    }
    if (target.getAttribute("aria-selected") === "true") states.push("selected");
    if (target.getAttribute("aria-pressed")  === "true") states.push("pressed");
    if (target.getAttribute("aria-haspopup")) states.push("opens menu");
    if (target instanceof HTMLAnchorElement && target.href) {
      if (target.href.startsWith("mailto:")) states.push("email link");
      else if (target.href.startsWith("tel:")) states.push("phone link");
    }
    if (states.length) parts.push(states.join(", "));

    const desc = getAriaDescribedByText(target);
    if (desc && desc !== rawName) parts.push(desc.slice(0,80));

    return parts.filter(Boolean).join(". ");
  }

  // ═══════════════════════════════════════════════════════════════
  // SCREEN-READER — narration engine
  // ═══════════════════════════════════════════════════════════════

  function speakNarration(text, onDone) {
    if (!("speechSynthesis" in window)) { if (onDone) onDone(); return; }
    if (isUserSpeaking) { if (onDone) onDone(); return; }
    const trimmed = (text || "").replace(/\s+/g," ").trim();
    if (!trimmed) { if (onDone) onDone(); return; }

    const id = ++narrateToken;
    let finished = false;
    const finish = () => { if (finished) return; finished = true; if (onDone) { try { onDone(); } catch (_) {} } };
    window.speechSynthesis.cancel();

    window.setTimeout(() => {
      if (id !== narrateToken) { finish(); return; }
      const utter  = new SpeechSynthesisUtterance(trimmed);
      const voice  = getPreferredVoice();
      utter.lang   = getPageLanguage();
      utter.rate   = Math.min(currentState.speechRate * 1.15, 2);
      utter.pitch  = currentState.speechPitch;
      if (voice) utter.voice = voice;

      const iv = window.setInterval(() => {
        if (!window.speechSynthesis.speaking || id !== narrateToken) {
          window.clearInterval(iv); return;
        }
        if (window.speechSynthesis.paused) window.speechSynthesis.resume();
      }, 250);

      // Safety net: if onend never fires (some Chrome builds), release anyway.
      const guard = window.setTimeout(finish, Math.max(3000, trimmed.length * 90));

      utter.onend   = () => { window.clearInterval(iv); window.clearTimeout(guard); finish(); };
      utter.onerror = () => { window.clearInterval(iv); window.clearTimeout(guard); finish(); };
      window.speechSynthesis.speak(utter);
    }, 60);
  }

  // ═══════════════════════════════════════════════════════════════
  // SCREEN-READER — event handlers
  // ═══════════════════════════════════════════════════════════════

  function setHoveredElement(el) {
    if (lastNarratedElement) lastNarratedElement.removeAttribute("data-extabilify-hovered");
    if (el) el.setAttribute("data-extabilify-hovered","");
    lastNarratedElement = el;
  }

  function onScreenReaderMouseMove(event) {
    if (hoverTimer) window.clearTimeout(hoverTimer);
    hoverTimer = window.setTimeout(() => {
      const el = document.elementFromPoint(event.clientX, event.clientY);
      if (!el || el === lastNarratedElement) return;
      const description = describeElement(el);
      if (!description) return;
      setHoveredElement(el);
      speakNarration(description);
    }, currentState.hoverDelay);       // ← configurable delay
  }

  function onScreenReaderScroll() {
    if (scrollNarrationTimer) window.clearTimeout(scrollNarrationTimer);
    scrollNarrationTimer = window.setTimeout(() => {
      const delta = window.scrollY - lastScrollY;
      if (Math.abs(delta) > 30)
        speakNarration(delta > 0 ? "Scrolling down" : "Scrolling up");
      lastScrollY = window.scrollY;
    }, 300);
  }

  function onScreenReaderFocusIn(event) {
    const el = event.target;
    if (!el || el === lastNarratedElement) return;
    const description = describeElement(el);
    if (!description) return;
    setHoveredElement(el);
    speakNarration(description);
  }

  // ── Browser UI zone detection ─────────────────────────────────────────────
  function guessBrowserZone(screenX, screenY) {
    const chromeH = window.outerHeight - window.innerHeight;
    if (chromeH <= 0) return null;
    const winLeft = window.screenX, winTop = window.screenY, winWidth = window.outerWidth;
    const relX = screenX - winLeft, relY = screenY - winTop;
    if (relY < 0 || relY >= chromeH) return null;
    const band = Math.max(30, Math.round(chromeH / (chromeH >= 85 ? 3 : 2)));
    if (relY < band) {
      if (relX > winWidth - 160) return "window control buttons — close, minimize, or maximize";
      if (relX < 60) return "browser menu or app icon";
      return "browser tab bar";
    }
    if (relX < 90) return "back and forward navigation buttons";
    if (relX > winWidth - 130) return "browser settings menu";
    return "address bar";
  }

  function onMouseLeaveDocument(event) {
    if (hoverTimer) { window.clearTimeout(hoverTimer); hoverTimer = null; }
    if (lastNarratedElement) {
      lastNarratedElement.removeAttribute("data-extabilify-hovered");
      lastNarratedElement = null;
    }
    const cx = event.clientX, cy = event.clientY;
    if (cy <= 0) {
      const zone = guessBrowserZone(event.screenX, event.screenY);
      speakNarration(zone ? `Mouse is on ${zone}` : "Mouse moved to browser toolbar area");
    } else if (cy >= window.innerHeight) speakNarration("Mouse moved below the page");
    else if (cx <= 0) speakNarration("Mouse moved to the left edge");
    else if (cx >= window.innerWidth) speakNarration("Mouse moved to the right edge");
  }

  function onMouseEnterDocument() { speakNarration("Mouse is back on the page"); }

  function onScreenReaderKeyDown(event) {
    if (!event.altKey || !event.shiftKey) return;
    if (event.key === "D" || event.key === "d") {
      event.preventDefault();
      const focused = document.activeElement;
      speakNarration(focused ? describeElement(focused) || "No description available." : "No element is focused.");
    }
    if (event.key === "R" || event.key === "r") {
      event.preventDefault();
      chrome.storage.local.get({ [STATE_KEY]: DEFAULT_STATE }, items => {
        const next = normalizeState(items[STATE_KEY]);
        next.screenReader = !next.screenReader;
        chrome.storage.local.set({ [STATE_KEY]: next });
      });
    }
  }

  function installScreenReaderListeners() {
    lastScrollY = window.scrollY; lastNarratedElement = null;
    document.addEventListener("mousemove",  onScreenReaderMouseMove, { passive: true });
    document.addEventListener("mouseleave", onMouseLeaveDocument, true);
    document.addEventListener("mouseenter", onMouseEnterDocument, true);
    window.addEventListener("scroll",       onScreenReaderScroll, { passive: true });
    document.addEventListener("focusin",    onScreenReaderFocusIn, true);
    document.addEventListener("keydown",    onScreenReaderKeyDown, true);
    const title = document.title.trim() || document.querySelector("h1")?.textContent?.trim() || "this page";
    speakWithProfile("voice_guide_on", `Voice guide is on. You are on ${title}. Press Alt Shift D to hear where you are.`);
  }

  function uninstallScreenReaderListeners() {
    document.removeEventListener("mousemove",  onScreenReaderMouseMove);
    document.removeEventListener("mouseleave", onMouseLeaveDocument, true);
    document.removeEventListener("mouseenter", onMouseEnterDocument, true);
    window.removeEventListener("scroll",       onScreenReaderScroll);
    document.removeEventListener("focusin",    onScreenReaderFocusIn, true);
    document.removeEventListener("keydown",    onScreenReaderKeyDown, true);
    if (hoverTimer) { window.clearTimeout(hoverTimer); hoverTimer = null; }
    if (scrollNarrationTimer) { window.clearTimeout(scrollNarrationTimer); scrollNarrationTimer = null; }
    if (lastNarratedElement) { lastNarratedElement.removeAttribute("data-extabilify-hovered"); lastNarratedElement = null; }
    narrateToken++;
    window.speechSynthesis.cancel();
    speakWithProfile("voice_guide_off", "Voice guide is off.");
  }

  // ═══════════════════════════════════════════════════════════════
  // VOICE COMMAND — engine (SpeechRecognition, like Siri)
  // ═══════════════════════════════════════════════════════════════

  function normalizeVoiceCommand(raw) {
    return String(raw || "")
      .toLowerCase()
      .replace(/[“”]/g, '"')
      .replace(/[’]/g, "'")
      .replace(/[?!.,;:]+/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .replace(/^(?:hey\s+)?(?:extabilify|accessibility|assistant)\s+/, "")
      .replace(/^(?:please|kindly)\s+/, "")
      .trim();
  }

  function createVoiceCommandPlan(rawCmd) {
    const command = normalizeVoiceCommand(rawCmd);
    const q = EXAM.active ? examCurrent() : null;
    return {
      raw: String(rawCmd || ""),
      command,
      route: EXAM.active ? "quiz" : "general",
      questionId: q ? q.id : null,
      questionStem: q ? q.stem : "",
      action: "",
      matched: false
    };
  }

  function initVcRecognition() {
    if (vcRecognition) return true;
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return false;
    vcRecognition = new SR();
    vcRecognition.continuous     = false;
    vcRecognition.interimResults  = false;
    vcRecognition.lang            = getPageLanguage();
    vcRecognition.maxAlternatives = 5;

    vcRecognition.onresult = event => {
      // A real result means the mic genuinely works — clear the failure count.
      vcConsecutiveFails = 0;
      // Try every alternative from every result until one is understood.
      let matched = false;
      for (let r = 0; r < event.results.length && !matched; r++) {
        const res = event.results[r];
        for (let i = 0; i < res.length && !matched; i++) {
          const t = (res[i].transcript || "").toLowerCase().trim();
          if (t) matched = processVoiceCommand(t);
        }
      }
      // Safety net: if nothing is speaking back (so onend's re-arm has nothing
      // to wait for) and we're still in listening mode, re-arm right away.
      if (vcLoop && !window.speechSynthesis.speaking) scheduleListen(250);
    };

    vcRecognition.onerror = event => {
      vcListening = false;
      if (event.error === "not-allowed" || event.error === "service-not-allowed") {
        vcConsecutiveFails = 0;
        vcManuallyPaused = true;
        stopListening();
        showToast("Microphone permission is needed for always-on voice commands. Click the mic/camera icon in the address bar to allow it, then press Alt+Shift+M.", 8000);
        return;
      }
      const soft = event.error === "no-speech" || event.error === "aborted" || event.error === "no-match";
      if (vcLoop && soft) { scheduleListen(300); return; }
      if (!vcLoop) showMicIndicator(false);
      if (!soft) showToast("Mic error: " + event.error);
    };

    vcRecognition.onend = () => {
      vcListening = false;
      if (vcLoop) {
        showMicIndicator(true);          // stay visibly "on" between utterances
        scheduleListen(350);
      } else {
        showMicIndicator(false);
      }
    };

    return true;
  }

  // Press once to start continuous listening; press again (or say "stop
  // listening") to turn the mic off. It never times out on its own — every
  // command re-arms it automatically once any reply has finished speaking.
  function startVoiceCommand() {
    if (!vcRecognition && !initVcRecognition()) {
      showToast("Your browser does not support voice commands. Try Chrome.");
      return;
    }
    if (vcLoop || vcListening) {
      vcManuallyPaused = true;
      stopListening();
      showToast("Voice commands stopped listening.");
      return;
    }
    vcConsecutiveFails = 0; // a deliberate press deserves a fresh attempt budget
    ensureVoiceCommandListening(true);
  }

  function ensureVoiceCommandListening(announce) {
    if (!vcRecognition && !initVcRecognition()) {
      showToast("Your browser does not support voice commands. Try Chrome.");
      return false;
    }
    vcManuallyPaused = false;
    if (vcLoop || vcListening) {
      showMicIndicator(true);
      scheduleListen(150);
      return true;
    }
    if (!announce) {
      scheduleListen(250);
      return true;
    }
    speakNarration("Listening. Say a command any time — I'll keep listening until you say \"stop listening\".",
      () => scheduleListen(150));
    return true;
  }

  // ── Continuous listening loop — shared by general commands and quiz mode ──
  function scheduleListen(delay) {
    if (vcRestartTimer) { window.clearTimeout(vcRestartTimer); vcRestartTimer = null; }
    vcManuallyPaused = false;
    vcLoop = true;
    vcRestartTimer = window.setTimeout(tryListen, Math.max(120, delay || 200));
  }

  function tryListen() {
    if (!vcLoop) return;
    if (!vcRecognition && !initVcRecognition()) {
      showToast("Voice needs Chrome. Use the keyboard shortcuts instead.");
      return;
    }
    // Don't listen over our own narration — poll until it's finished.
    if (window.speechSynthesis && window.speechSynthesis.speaking) {
      vcRestartTimer = window.setTimeout(tryListen, 250);
      return;
    }
    if (vcListening) return;
    // Give up gracefully after repeated failed attempts (e.g. a browser that
    // never resolves the mic permission prompt) instead of retrying forever
    // and re-triggering that prompt every time.
    if (vcConsecutiveFails >= VC_MAX_CONSECUTIVE_FAILS) {
      vcConsecutiveFails = 0;
      vcManuallyPaused = true;
      stopListening();
      showToast(
        "The microphone isn't responding. Check your browser's microphone permission for this page " +
        "(click the mic/camera icon in the address bar), then press Alt+Shift+M or the mic button to try again.",
        9000
      );
      return;
    }
    try {
      vcListening = true;
      vcConsecutiveFails++;      // optimistic; cleared by onresult on a real success
      showMicIndicator(true);
      vcRecognition.start();
    } catch (_) {
      // "already started" or a transient race — back off and retry once.
      vcListening = false;
      vcRestartTimer = window.setTimeout(tryListen, 500);
    }
  }

  function stopListening() {
    vcLoop = false;
    if (vcRestartTimer) { window.clearTimeout(vcRestartTimer); vcRestartTimer = null; }
    if (vcListening && vcRecognition) { try { vcRecognition.abort(); } catch (_) {} }
    vcListening = false;
    showMicIndicator(false);
  }

  // Speak, then immediately re-open the mic once the voice stops (if we're
  // still meant to be listening). Used for quiz-mode prompts, which need a
  // fast, guaranteed re-arm; general commands also re-arm via onend/onresult.
  function sayThenListen(text) {
    speakNarration(text, () => { if (vcLoop) scheduleListen(150); });
  }

  function showMicIndicator(visible) {
    const m = ensureMicIndicator();
    const label = EXAM.active
      ? "Listening — say “choose B”, “next”, “repeat”…"
      : "Listening — say a command, or “stop listening” to pause";
    m.textContent = visible ? label : "";
    m.dataset.visible = visible ? "true" : "false";
  }

  const COMMAND_STOP_WORDS = new Set([
    "a", "an", "and", "can", "could", "for", "i", "me", "my", "now", "of",
    "on", "please", "the", "this", "to", "you", "would"
  ]);

  function tokenizeCommand(text) {
    return normalizeVoiceCommand(text)
      .split(/\s+/)
      .map(t => t.trim())
      .filter(t => t && !COMMAND_STOP_WORDS.has(t));
  }

  function commandHasWords(cmd, words) {
    const tokens = tokenizeCommand(cmd);
    return words.every(w => tokens.includes(w));
  }

  function commandTail(cmd, starts) {
    for (const start of starts || []) {
      if (cmd === start) return "";
      if (cmd.startsWith(start + " ")) return cmd.slice(start.length).trim();
    }
    return "";
  }

  const VOICE_COMMAND_DICTIONARY = [
    { id:"stop_listening", scope:"all", phrases:["stop listening","pause listening","go to sleep","stop voice commands","turn off microphone","turn off the mic","mic off","microphone off"], keywords:["stop","listening"], action:"stop_listening" },
    { id:"help", scope:"all", phrases:["help","commands","what can i say","what can you do","voice commands","show commands","tell me the commands"], keywords:["help"], action:"help" },
    { id:"where_am_i", scope:"general", phrases:["where am i","what page am i on","describe page","what is this page","current page","tell me where i am"], keywords:["where"], action:"where_am_i" },
    { id:"open_settings", scope:"general", phrases:["settings","open settings","my settings","go to settings","change settings","extension settings"], keywords:["settings"], action:"open_settings" },
    { id:"reset", scope:"general", phrases:["reset","reset all","reset settings","start over","restore defaults","normal settings"], keywords:["reset"], action:"reset" },
    { id:"scroll_down", scope:"general", phrases:["scroll down","go down","move down","page down","down the page","lower down","show more below"], patterns:[/\b(scroll|move|go|page)\b.*\bdown\b/, /\b(show|take)\b.*\bbelow\b/], action:"scroll_down" },
    { id:"scroll_up", scope:"general", phrases:["scroll up","go up","move up","page up","up the page","higher up","show above"], patterns:[/\b(scroll|move|go|page)\b.*\bup\b/, /\b(show|take)\b.*\babove\b/], action:"scroll_up" },
    { id:"scroll_top", scope:"general", phrases:["top","go to top","scroll to top","go to beginning","start of page","back to top","top of page"], patterns:[/\b(top|beginning|start)\b.*\b(page)?\b/], action:"scroll_top" },
    { id:"scroll_bottom", scope:"general", phrases:["bottom","go to bottom","scroll to bottom","end","end of page","last part of page"], patterns:[/\b(bottom|end)\b.*\b(page)?\b/], action:"scroll_bottom" },
    { id:"scroll_left", scope:"general", phrases:["scroll left","move left","pan left","go left"], keywords:["left"], action:"scroll_left" },
    { id:"scroll_right", scope:"general", phrases:["scroll right","move right","pan right","go right"], keywords:["right"], action:"scroll_right" },
    { id:"go_back", scope:"general", phrases:["go back","back","previous page","browser back","return to last page"], keywords:["back"], action:"go_back" },
    { id:"go_forward", scope:"general", phrases:["go forward","forward","next page","browser forward"], keywords:["forward"], action:"go_forward" },
    { id:"reload", scope:"general", phrases:["refresh","reload","reload page","refresh page","try again"], keywords:["reload"], action:"reload" },
    { id:"read_page", scope:"general", phrases:["read","read page","read aloud","read this page","read everything","speak page","say the page"], patterns:[/\b(read|speak|say)\b.*\b(page|everything|all)\b/], action:"read_page" },
    { id:"read_selection", scope:"general", phrases:["read selection","read selected text","read highlighted text","speak selection","read what i selected"], patterns:[/\b(read|speak)\b.*\b(selection|selected|highlighted)\b/], action:"read_selection" },
    { id:"read_main", scope:"general", phrases:["read main","read main part","read the main part","read article","read content","read the lesson","read the passage"], patterns:[/\b(read|speak)\b.*\b(main|article|content|lesson|passage)\b/], action:"read_main" },
    { id:"stop_reading", scope:"general", phrases:["stop","stop reading","quiet","silence","pause reading","be quiet","stop talking"], patterns:[/\b(stop|pause|quiet|silence)\b.*\b(reading|talking|voice)?\b/], action:"stop_reading" },
    { id:"text_bigger", scope:"general", phrases:["bigger","make bigger","larger text","increase text","zoom in","make letters bigger","bigger letters","text bigger"], keywords:["bigger"], action:"text_bigger" },
    { id:"text_smaller", scope:"general", phrases:["smaller","make smaller","smaller text","decrease text","zoom out","make letters smaller","smaller letters","text smaller"], keywords:["smaller"], action:"text_smaller" },
    { id:"text_normal", scope:"general", phrases:["normal text","reset text size","default text size","regular letters","normal letters"], keywords:["normal","text"], action:"text_normal" },
    { id:"contrast_toggle", scope:"general", phrases:["dark mode","high contrast","sharper screen","toggle contrast","contrast mode"], keywords:["contrast"], action:"contrast_toggle" },
    { id:"contrast_on", scope:"general", phrases:["turn on dark mode","dark mode on","turn on high contrast","high contrast on","sharper screen on"], keywords:["dark","on"], action:"contrast_on" },
    { id:"contrast_off", scope:"general", phrases:["turn off dark mode","dark mode off","turn off high contrast","high contrast off","sharper screen off"], keywords:["dark","off"], action:"contrast_off" },
    { id:"focus_toggle", scope:"general", phrases:["focus mode","clear page","reading mode","hide distractions","clean page"], keywords:["focus"], action:"focus_toggle" },
    { id:"focus_on", scope:"general", phrases:["turn on focus mode","focus mode on","clear page on","hide distractions now"], keywords:["focus","on"], action:"focus_on" },
    { id:"focus_off", scope:"general", phrases:["turn off focus mode","focus mode off","clear page off","show distractions"], keywords:["focus","off"], action:"focus_off" },
    { id:"screen_reader_toggle", scope:"general", phrases:["voice guide","screen reader","toggle voice guide","read my screen"], keywords:["guide"], action:"screen_reader_toggle" },
    { id:"screen_reader_on", scope:"general", phrases:["voice guide on","turn on voice guide","screen reader on","turn on screen reader"], keywords:["guide","on"], action:"screen_reader_on" },
    { id:"screen_reader_off", scope:"general", phrases:["voice guide off","turn off voice guide","screen reader off","turn off screen reader"], keywords:["guide","off"], action:"screen_reader_off" },
    { id:"spacing_toggle", scope:"general", phrases:["reading space","spacing","more space","line spacing","space out text"], keywords:["spacing"], action:"spacing_toggle" },
    { id:"spacing_on", scope:"general", phrases:["reading space on","turn on spacing","more space on","increase spacing"], keywords:["spacing","on"], action:"spacing_on" },
    { id:"spacing_off", scope:"general", phrases:["reading space off","turn off spacing","spacing off","normal spacing"], keywords:["spacing","off"], action:"spacing_off" },
    { id:"smart_toggle", scope:"general", phrases:["smart reading","smart reader","smart page","annotate page","label page","fix page"], keywords:["smart"], action:"smart_toggle" },
    { id:"smart_on", scope:"general", phrases:["smart reading on","turn on smart reading","label this page","fix this page","make page accessible"], keywords:["smart","on"], action:"smart_on" },
    { id:"smart_off", scope:"general", phrases:["smart reading off","turn off smart reading","stop smart reading"], keywords:["smart","off"], action:"smart_off" },
    { id:"quiz_start", scope:"general", phrases:["quiz mode","exam mode","start quiz","start exam","begin quiz","take quiz","answer quiz","do quiz","start the quiz","help me with quiz"], patterns:[/\b(start|begin|take|do|answer)\b.*\b(quiz|exam|test)\b/], action:"quiz_start" },
    { id:"find_text", scope:"general", phrases:["find","search for","look for","highlight","go to text"], patterns:[/^(?:find|search for|look for|highlight|go to)\s+(.+)$/], action:"find_text", argStarts:["find","search for","look for","highlight","go to"] },
    { id:"click_label", scope:"general", phrases:["click","press","tap","select","open button","choose button"], patterns:[/^(?:click|press|tap|select|open)\s+(.+)$/], action:"click_label", argStarts:["click","press","tap","select","open"] },
    { id:"quiz_next", scope:"quiz", phrases:["next","next question","next one","continue","move on","go on","skip","forward","please continue"], keywords:["next"], action:"quiz_next" },
    { id:"quiz_previous", scope:"quiz", phrases:["previous","previous question","prev","go back","back","back one","last question","prior question"], keywords:["previous"], action:"quiz_previous" },
    { id:"quiz_repeat", scope:"quiz", phrases:["repeat","repeat question","repeat that","read question","read again","say again","what was the question"], keywords:["repeat"], action:"quiz_repeat" },
    { id:"quiz_options", scope:"quiz", phrases:["read options","list options","what are the options","choices","read choices","tell me the choices"], keywords:["options"], action:"quiz_options" },
    { id:"quiz_progress", scope:"quiz", phrases:["progress","my progress","score","status","how many left","how many answered","where am i"], keywords:["progress"], action:"quiz_progress" },
    { id:"quiz_submit", scope:"quiz", phrases:["submit","finish","finish quiz","submit quiz","submit answers","hand in","i am done","complete quiz","send answers","send it"], keywords:["submit"], action:"quiz_submit" },
    { id:"quiz_exit", scope:"quiz", phrases:["exit quiz","leave quiz","stop quiz","quit quiz","exit exam","close quiz","end quiz","cancel quiz"], keywords:["exit","quiz"], action:"quiz_exit" },
    { id:"quiz_goto", scope:"quiz", phrases:["go to question","jump to question","open question","show question"], patterns:[/\b(?:go to|jump to|open|show)\s+(?:question\s+)?(\d+|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)\b/, /^question\s+(\d+)$/], action:"quiz_goto" },
    { id:"quiz_answer", scope:"quiz", phrases:["choose","select option","answer","pick","mark","tick","check","go with","the answer is","i choose","i pick"], patterns:[/\b(?:choose|select|answer|pick|mark|tick|check|go with|the answer is|answer is|it is|it's|its)\s+(?:option\s+|letter\s+|number\s+|the\s+)?(.+)$/], action:"quiz_answer" }
  ];

  const DICTIONARY_BY_ID = {};
  VOICE_COMMAND_DICTIONARY.forEach(def => { DICTIONARY_BY_ID[def.id] = def; });

  function matchCommandDefinition(cmd, scope) {
    let best = null;
    for (const def of VOICE_COMMAND_DICTIONARY) {
      if (def.scope !== "all" && def.scope !== scope) continue;
      let score = 0, match = null;
      for (const phrase of def.phrases || []) {
        if (cmd === phrase) score = Math.max(score, 100);
        else if (phrase.length > 3 && cmd.includes(phrase)) score = Math.max(score, 86);
      }
      for (const pattern of def.patterns || []) {
        const m = cmd.match(pattern);
        if (m) { score = Math.max(score, 94); match = m; }
      }
      if (def.keywords && commandHasWords(cmd, def.keywords)) score = Math.max(score, 74 + def.keywords.length);
      if (score && (!best || score > best.score)) best = { def, score, match };
    }
    return best && best.score >= 74 ? best : null;
  }

  function setStoredState(mutator, spoken) {
    chrome.storage.local.get({ [STATE_KEY]: DEFAULT_STATE }, items => {
      const s = normalizeState(items[STATE_KEY]);
      mutator(s);
      chrome.storage.local.set({ [STATE_KEY]: s });
      if (spoken) speakNarration(typeof spoken === "function" ? spoken(s) : spoken);
    });
  }

  function readPageBlock(kind) {
    const sel = window.getSelection()?.toString().trim();
    if (kind === "selection" && sel) { speakSelectionText(sel, getPageLanguage()); return; }
    const block = kind === "main"
      ? ((currentState.smartReader && findDenseBlock()) || document.querySelector("main,article,[role='main']"))
      : document.querySelector("main,article,[role='main'],.main-content");
    const text = (block ? block.innerText : document.body.innerText).slice(0, kind === "main" ? 4000 : 2000);
    speakSelectionText(text || "Nothing to read on this page.", getPageLanguage());
  }

  function numberFromSpoken(value) {
    const raw = normalizeVoiceCommand(value);
    if (/^\d+$/.test(raw)) return +raw;
    return NUMWORD[raw] || 0;
  }

  function executeDictionaryCommand(match, cmd, plan) {
    const { def } = match;
    if (plan) { plan.action = def.id; plan.matched = true; }
    switch (def.action) {
      case "stop_listening": vcManuallyPaused = true; stopListening(); speakNarration("Voice commands paused. Press Alt Shift M, or the microphone button, to start listening again."); return true;
      case "help": speakNarration(EXAM.active ? "Quiz commands: next, back, repeat, read options, choose a letter or option text, go to question number, progress, submit, or exit quiz. Say info followed by a question, like info progress, any time to ask about the quiz without changing your answer." : "You can say scroll, read, find text, click a button, bigger or smaller text, dark mode, focus mode, voice guide, smart reading, quiz mode, settings, reset, or help."); showToast("Voice commands available.", 6000); return true;
      case "where_am_i": { const title = document.title || document.querySelector("h1")?.textContent || "an unknown page"; speakNarration(`You are on ${title}, at ${location.hostname}`); return true; }
      case "open_settings": chrome.runtime.sendMessage({ type: "EXTABILIFY_OPEN_SETTINGS" }); speakNarration("Opening settings"); return true;
      case "reset": chrome.storage.local.set({ [STATE_KEY]: DEFAULT_STATE }); speakNarration("All settings reset"); return true;
      case "scroll_down": window.scrollBy({ top: 400, behavior: "smooth" }); speakNarration("Scrolling down"); return true;
      case "scroll_up": window.scrollBy({ top: -400, behavior: "smooth" }); speakNarration("Scrolling up"); return true;
      case "scroll_top": window.scrollTo({ top: 0, behavior: "smooth" }); speakNarration("Going to top of page"); return true;
      case "scroll_bottom": window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" }); speakNarration("Going to bottom of page"); return true;
      case "scroll_left": window.scrollBy({ left: -400, behavior: "smooth" }); speakNarration("Scrolling left"); return true;
      case "scroll_right": window.scrollBy({ left: 400, behavior: "smooth" }); speakNarration("Scrolling right"); return true;
      case "go_back": speakNarration("Going back"); window.history.back(); return true;
      case "go_forward": speakNarration("Going forward"); window.history.forward(); return true;
      case "reload": speakNarration("Refreshing page"); window.location.reload(); return true;
      case "read_page": readPageBlock("page"); return true;
      case "read_selection": readPageBlock("selection"); return true;
      case "read_main": readPageBlock("main"); return true;
      case "stop_reading": window.speechSynthesis.cancel(); isUserSpeaking = false; showToast("Stopped."); return true;
      case "text_bigger": setStoredState(s => { s.textScale = Math.min(s.textScale + 0.1, 2.0); }, s => `Text size ${Math.round(s.textScale * 100)} percent`); return true;
      case "text_smaller": setStoredState(s => { s.textScale = Math.max(s.textScale - 0.1, 0.8); }, s => `Text size ${Math.round(s.textScale * 100)} percent`); return true;
      case "text_normal": setStoredState(s => { s.textScale = 1; }, "Text size normal"); return true;
      case "contrast_toggle": setStoredState(s => { s.contrast = !s.contrast; }, s => s.contrast ? "Dark mode on" : "Dark mode off"); return true;
      case "contrast_on": setStoredState(s => { s.contrast = true; }, "Dark mode on"); return true;
      case "contrast_off": setStoredState(s => { s.contrast = false; }, "Dark mode off"); return true;
      case "focus_toggle": setStoredState(s => { s.focusMode = !s.focusMode; }, s => s.focusMode ? "Focus mode on" : "Focus mode off"); return true;
      case "focus_on": setStoredState(s => { s.focusMode = true; }, "Focus mode on"); return true;
      case "focus_off": setStoredState(s => { s.focusMode = false; }, "Focus mode off"); return true;
      case "screen_reader_toggle": setStoredState(s => { s.screenReader = !s.screenReader; }); return true;
      case "screen_reader_on": setStoredState(s => { s.screenReader = true; }); return true;
      case "screen_reader_off": setStoredState(s => { s.screenReader = false; }); return true;
      case "spacing_toggle": setStoredState(s => { s.spacing = !s.spacing; }, s => s.spacing ? "Reading space on" : "Reading space off"); return true;
      case "spacing_on": setStoredState(s => { s.spacing = true; }, "Reading space on"); return true;
      case "spacing_off": setStoredState(s => { s.spacing = false; }, "Reading space off"); return true;
      case "smart_toggle": toggleStateKey("smartReader"); return true;
      case "smart_on": setStoredState(s => { s.smartReader = true; }, "Smart reading on"); return true;
      case "smart_off": setStoredState(s => { s.smartReader = false; }, "Smart reading off"); return true;
      case "quiz_start": if (!currentState.smartReader) toggleStateKey("smartReader"); examStart(); return true;
      case "find_text": { const arg = (match.match && match.match[1]) || commandTail(cmd, def.argStarts); if (arg) { findTextOnPage(arg); return true; } break; }
      case "click_label": { const arg = (match.match && match.match[1]) || commandTail(cmd, def.argStarts); if (arg) { clickElementByLabel(arg); return true; } break; }
      case "quiz_next": examGo(1); return true;
      case "quiz_previous": examGo(-1); return true;
      case "quiz_repeat": EXAM.autoAdvancePending = false; examRead(); return true;
      case "quiz_options": EXAM.autoAdvancePending = false; examRead(true); return true;
      case "quiz_progress": { const p = examProgress(); const left = EXAM.questions.filter(q => !examAnsweredLetters(q).length).map(q => q.id); sayThenListen(`${p.done} of ${p.total} answered.` + (left.length ? ` Still open: question ${left.join(", ")}.` : " All done.")); return true; }
      case "quiz_submit": examSubmit(); return true;
      case "quiz_exit": examStop(); return true;
      case "quiz_goto": { const n = numberFromSpoken((match.match && match.match[1]) || cmd.replace(/\D+/g, "")); if (n) { examGoTo(n); return true; } break; }
      case "quiz_answer": {
        const spoken = (match.match && match.match[1]) || cmd;
        const q = examCurrent();
        if (q && q.type === "multi") {
          const multi = parseMultiAnswerTokens(spoken, q);
          if (multi) { if (plan) plan.action = `answer:${multi.join("+")}`; examAnswerMulti(multi); return true; }
        }
        const L = resolveAnswerToken(spoken, q, false);
        if (L) { if (plan) plan.action = `answer:${L}`; examAnswer(L); return true; }
        break;
      }
    }
    return false;
  }

  // ── Voice logging — one line for what was heard, one for how it was
  // resolved, always, so behaviour can be audited from the page console. ────
  function logVoiceHeard(plan) {
    console.log(`[Extabilify voice] heard: "${plan.raw}"${plan.raw.trim().toLowerCase() !== plan.command ? ` → normalized: "${plan.command}"` : ""}`);
  }
  function logVoiceRefined(plan, source) {
    console.log(`[Extabilify voice] refined (${source}): action="${plan.action || "no_match"}"`);
  }

  // ── Magic-word meta channel — quiz-only, read-only info queries ──────────
  // Saying the magic word anywhere in an utterance (even mid "answer") routes
  // straight to progress/repeat/options/help and NEVER to answer, submit,
  // next, previous, exit, or goto — so it can never be used to skip, submit,
  // or otherwise change the quiz, only to ask about it.
  const QUIZ_META_WORD = "info";
  const QUIZ_META_ACTIONS = new Set(["quiz_progress", "quiz_options", "quiz_repeat", "help"]);

  function tryHandleQuizMetaQuery(cmd, plan) {
    const tokens = cmd.split(/\s+/).filter(Boolean);
    if (!tokens.includes(QUIZ_META_WORD)) return false;
    const rest = tokens.filter(t => t !== QUIZ_META_WORD).join(" ").trim();
    const local = rest ? matchCommandDefinition(rest, "quiz") : null;
    const def = (local && QUIZ_META_ACTIONS.has(local.def.id))
      ? local.def
      : DICTIONARY_BY_ID.quiz_progress; // bare "info" → "how am I doing"
    if (plan) plan.action = `meta:${def.id}`;
    executeDictionaryCommand({ def, score: 100, match: null }, rest, plan);
    return true;
  }

  // ── Command processor — returns true if command was understood ────────────
  function processVoiceCommand(cmd) {
    const plan = createVoiceCommandPlan(cmd);
    lastVoiceCommandPlan = plan;
    cmd = plan.command;
    const myGen = ++voiceCommandGen;
    if (!cmd) return false;
    logVoiceHeard(plan);

    // Quiz meta-info queries ("...info...") take priority over everything,
    // including the exam engine's own answer parsing, and can never mutate
    // quiz state — only report on it.
    if (EXAM.active && tryHandleQuizMetaQuery(cmd, plan)) {
      plan.matched = true;
      logVoiceRefined(plan, "local");
      return true;
    }

    // While a quiz is running, quiz commands take priority over general ones.
    if (EXAM.active && handleExamCommand(cmd, plan)) {
      plan.matched = true;
      logVoiceRefined(plan, "local");
      return true;
    }

    // General commands (scroll, read, dark mode, help, ...) are also
    // available as a fallback while a quiz is active, exactly as they were
    // before — e.g. "dark mode" still works mid-quiz if it isn't a quiz
    // command itself.
    const match = matchCommandDefinition(cmd, "general");
    if (match && executeDictionaryCommand(match, cmd, plan)) {
      plan.matched = true;
      logVoiceRefined(plan, "local");
      return true;
    }

    logVoiceRefined(plan, "local");

    // Local pattern matching couldn't resolve it. Two things happen at once,
    // neither blocking the other:
    //  1) if AI-assisted refinement is configured, the original utterance is
    //     sent off to purify it into one of our known commands (never to
    //     answer the question itself) — this runs in the background;
    //  2) the student is told right away to just try saying it again, so
    //     they are never sitting in silence waiting on network latency.
    // If the AI resolves something useful before the student's next
    // utterance, it speaks up on its own (see tryAiRefine) and naturally
    // supersedes this prompt. If the student has already spoken again by
    // then, the AI's reply for this earlier utterance is simply discarded
    // (see the myGen staleness check) — whatever the student says next wins.
    tryAiRefine(cmd, plan, myGen);
    if (EXAM.active) {
      sayThenListen(`Sorry, I didn't catch that — please say it again, or say the letter of your answer.`);
    } else {
      speakNarration(`Sorry, I didn't catch that — please say it again, or say help for a list of commands.`);
    }
    return false;
  }

  // ── AI-drafted message safety filter ──────────────────────────────────────
  // Defense in depth on top of the system prompt (see background.js): the
  // model is never given the question stem or option text, so it has no
  // legitimate content to leak — but this is a second, independent check
  // that refuses to ever speak anything that reads like it's stating or
  // hinting at a quiz answer, regardless of what the model was told.
  const UNSAFE_AI_MESSAGE_PATTERNS = [
    /\bthe answer is\b/i, /\bcorrect answer\b/i, /\bright answer\b/i, /\bwrong answer\b/i,
    /\byou should (choose|pick|select|answer|say)\b/i,
    /\bi (recommend|suggest|think|believe)\b.*\b(option|answer|choice|choosing|picking)\b/i,
    /\boption\s+[a-j]\b.*\b(is|was)\b.*\b(correct|right|wrong|the answer)\b/i,
    /\b(correct|right)\s+(option|choice|letter)\b/i
  ];
  function isSafeAiMessage(text) {
    if (!text || typeof text !== "string") return false;
    const trimmed = text.trim();
    if (!trimmed || trimmed.length > 240) return false;
    return !UNSAFE_AI_MESSAGE_PATTERNS.some(re => re.test(trimmed));
  }

  // Generic, content-free snapshot of the current question's control
  // structure — enough for the model to give page-aware guidance ("this
  // page uses custom clickable boxes, not real checkboxes") without ever
  // seeing the question or option text, so it has nothing quiz-specific to
  // leak. Works the same regardless of which school's site built the quiz.
  function examControlMeta(q) {
    if (!q) return null;
    const native = q.options.every(o => o.input.tagName === "INPUT");
    return {
      questionId: q.id,
      totalQuestions: EXAM.questions.length,
      optionCount: q.options.length,
      optionLetters: q.options.map(o => o.letter),
      type: q.type,
      selectedCount: examAnsweredLetters(q).length,
      controlKind: native ? "native-input" : "custom-aria-widget"
    };
  }

  // Structural (never textual-content) snapshot of the page, so the model
  // can be a little more specific ("this page has no main landmark, so...")
  // without ever being handed page body text.
  function pageStructureMeta() {
    return {
      title: document.title ? document.title.slice(0, 80) : "",
      hasMainLandmark: !!document.querySelector("main,[role=main],article"),
      navCount: document.querySelectorAll("nav,[role=navigation]").length,
      formCount: document.querySelectorAll("form").length,
      smartReaderOn: !!currentState.smartReader
    };
  }

  // ── AI-assisted refinement (optional) ─────────────────────────────────────
  // Only reached when local matching found nothing. Sends the raw transcript
  // to background.js, which — only if the user configured an OpenAI key in
  // Settings — asks the model to classify it into ONE of our existing command
  // ids (never to invent an answer). When it can't (action "no_match"), the
  // model may also draft a short, page-structure-aware help message — never
  // given the question or option text, so it has nothing to leak, and
  // independently checked by isSafeAiMessage() before it's ever spoken.
  //
  // The caller has ALREADY told the student to just try saying it again
  // immediately, without waiting for this — so this function only speaks up
  // when it has something genuinely new to add (a resolved action, or a
  // safety-checked drafted message). On failure, disabled, or a plain
  // no_match with nothing useful to say, it stays silent rather than
  // repeating the same "I didn't understand" the student already heard.
  function tryAiRefine(cmd, plan, myGen) {
    if (!chrome.runtime || !chrome.runtime.sendMessage) return false;
    const scope = EXAM.active ? "quiz" : "general";
    const allowedActions = VOICE_COMMAND_DICTIONARY
      .filter(d => d.scope === "all" || d.scope === scope)
      .map(d => d.id);
    const q = EXAM.active ? examCurrent() : null;

    // Full transparency, printed every single time local matching fails:
    // AI assist is the only path in the whole extension that can leave the
    // device, so nothing about it is silent. This line alone does not mean
    // a network call happened — background.js only actually contacts
    // OpenAI if AI voice assist is turned on with a key in Settings; if it
    // isn't, the very next line logged will say so and nothing is sent
    // anywhere. When it IS enabled, OpenAI's exact raw reply is logged too
    // (below), so both sides of the exchange are always visible here.
    console.log(`[Extabilify voice] AI voice assist: requesting refinement for exact wording: "${cmd}" (only reaches OpenAI if enabled in Settings)`);

    let dispatched = false;
    try {
      chrome.runtime.sendMessage({
        type: "EXTABILIFY_AI_REFINE",
        transcript: cmd,
        scope,
        allowedActions,
        quizContext: q ? examControlMeta(q) : null,
        pageContext: pageStructureMeta()
      }, response => {
        if (chrome.runtime.lastError) return; // no background listener / port closed
        if (myGen !== voiceCommandGen) {
          console.log("[Extabilify voice] refined (ai): stale reply ignored — a newer command already ran");
          return;
        }
        if (!response || !response.ok) {
          console.log(`[Extabilify voice] refined (ai): ${(response && response.reason) || "unavailable"}`);
          if (response && response.raw) console.log(`[Extabilify voice] OpenAI raw reply (rejected): ${response.raw}`);
          return; // the "please say it again" prompt already covered this
        }
        // The exact, unmodified text OpenAI returned — logged before any of
        // our own interpretation, filtering, or safety checks below.
        if (response.raw) console.log(`[Extabilify voice] OpenAI raw reply: ${response.raw}`);
        const action = response.action;
        console.log(`[Extabilify voice] refined (ai): action="${action || "no_match"}" arg=${JSON.stringify(response.arg || null)}`);
        const def = action && allowedActions.includes(action) ? DICTIONARY_BY_ID[action] : null;
        if (!def) {
          const safeMessage = isSafeAiMessage(response.message) ? response.message.trim() : "";
          if (safeMessage) {
            console.log(`[Extabilify voice] refined (ai): no_match, drafted message: "${safeMessage}"`);
            if (EXAM.active) sayThenListen(safeMessage); else speakNarration(safeMessage);
          } else if (response.message) {
            console.log(`[Extabilify voice] refined (ai): drafted message rejected by safety filter — staying silent`);
          }
          return;
        }
        if (plan) plan.action = `ai:${action}`;
        const fakeMatch = response.arg != null ? [null, String(response.arg)] : null;
        executeDictionaryCommand({ def, score: 100, match: fakeMatch }, cmd, plan);
      });
      dispatched = true;
    } catch (_) {
      dispatched = false;
    }
    return dispatched;
  }

  // ── Find text on page ─────────────────────────────────────────────────────
  function findTextOnPage(searchText) {
    document.querySelectorAll("[data-extabilify-found]")
      .forEach(el => el.removeAttribute("data-extabilify-found"));

    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
    let node, found = false;
    while ((node = walker.nextNode())) {
      if (node.textContent.toLowerCase().includes(searchText.toLowerCase())) {
        const parent = node.parentElement;
        if (parent && !parent.closest(`#${TOAST_ID},#${ANNOUNCER_ID},#${MIC_INDICATOR_ID}`)) {
          parent.setAttribute("data-extabilify-found","");
          parent.scrollIntoView({ behavior: "smooth", block: "center" });
          parent.focus({ preventScroll: true });
          speakNarration(`Found: ${node.textContent.trim().slice(0,120)}`);
          found = true; break;
        }
      }
    }
    if (!found) speakNarration(`Could not find "${searchText}" on this page`);
  }

  // Phrases that are reserved quiz commands and must never be mistaken for a
  // spoken option label (e.g. so a question with an option literally called
  // "Next" can't accidentally trigger by saying "next").
  const QUIZ_RESERVED_BARE = new Set([
    "next", "next question", "previous", "previous question", "repeat",
    "read options", "progress", "submit", "finish", "finish quiz",
    "submit quiz", "exit quiz", "leave quiz", "stop quiz", "quit quiz",
    "help", "commands"
  ]);

  // ── Quiz voice commands (only consulted while EXAM.active) ───────────────
  // Backed by the shared VOICE_COMMAND_DICTIONARY (scope "quiz"/"all") so the
  // ~50 command definitions and their 280+ phrase variants are the single
  // source of truth; only the bare-answer case (a lone letter, NATO word, or
  // spoken option label with no trigger word) is quiz-specific enough to
  // need its own logic here.
  function handleExamCommand(rawCmd, plan) {
    const cmd = rawCmd.replace(/[?!.]+$/, "").trim();
    if (!cmd) return false;

    const match = matchCommandDefinition(cmd, "quiz");
    if (match && executeDictionaryCommand(match, cmd, plan)) return true;

    // bare checkbox multi-answer: "A and C", "Twi and Zulu" — no trigger
    // word, so it never reaches the dictionary's quiz_answer pattern above.
    const q = examCurrent();
    if (q && q.type === "multi") {
      const multi = parseMultiAnswerTokens(cmd, q);
      if (multi) {
        if (plan) plan.action = `answer:${multi.join("+")}`;
        examAnswerMulti(multi);
        return true;
      }
    }

    // bare answer: "B", "bravo", "2", "bee", or the spoken option label
    // such as "Accra" while a question is showing. Reserved command phrases
    // ("next", "progress", ...) never get tried as a spoken option label —
    // only as a letter/NATO/number, which they'll never match anyway.
    const bare = QUIZ_RESERVED_BARE.has(cmd) ? parseAnswerToken(cmd) : resolveAnswerToken(cmd, q, false);
    if (bare) {
      if (plan) plan.action = `answer:${bare}`;
      examAnswer(bare);
      return true;
    }

    return false;
  }

  // ── Click element by accessible label ─────────────────────────────────────
  function clickElementByLabel(labelText) {
    const candidates = document.querySelectorAll(
      "a[href],button,input:not([type=hidden]),select,textarea,[role=button],[role=link],[tabindex]:not([tabindex='-1'])"
    );
    const lower = labelText.toLowerCase();
    for (const el of candidates) {
      const name = (
        el.getAttribute("aria-label") || el.getAttribute("title") ||
        el.textContent || el.getAttribute("placeholder") || el.getAttribute("alt") || ""
      ).toLowerCase().trim();
      if (name.includes(lower)) {
        el.click(); el.focus({ preventScroll: true });
        speakNarration(`Clicked ${name.slice(0,80)}`); return;
      }
    }
    speakNarration(`Could not find a button or link named "${labelText}"`);
  }

  // ── Voice command keyboard shortcut: Alt+Shift+M ──────────────────────────
  function onVcKeyDown(event) {
    if (event.altKey && event.shiftKey && (event.key === "M" || event.key === "m")) {
      event.preventDefault();
      startVoiceCommand();
    }
  }

  function onVoiceCommandWake() {
    if (document.hidden || vcManuallyPaused) return;
    if (currentState.voiceCommand || EXAM.active) ensureVoiceCommandListening(false);
  }

  const VC_UNSUPPORTED_SEEN_KEY = "extabilifyVoiceUnsupportedSeen";

  function installVoiceCommand() {
    if (!initVcRecognition()) {
      // Voice commands need the browser's own speech-recognition engine —
      // Chrome and Edge have it, Firefox does not implement it at all (still
      // behind an experimental flag, never shipped to release, as of 2026).
      // voiceCommand defaults to on, so this runs on every single page load
      // in an unsupported browser — inform the student once, ever, instead
      // of nagging on every page they visit.
      chrome.storage.local.get({ [VC_UNSUPPORTED_SEEN_KEY]: false }, items => {
        if (items[VC_UNSUPPORTED_SEEN_KEY]) return;
        showToast(
          "Voice commands need Chrome or Edge — this browser doesn't support the speech recognition they use. " +
          "Everything else here (reading aloud, quiz mode by keyboard, contrast, text size, and more) still works.",
          8000
        );
        chrome.storage.local.set({ [VC_UNSUPPORTED_SEEN_KEY]: true });
      });
      return;
    }
    document.addEventListener("keydown", onVcKeyDown, true);
    document.addEventListener("visibilitychange", onVoiceCommandWake, true);
    window.addEventListener("focus", onVoiceCommandWake, true);
    window.addEventListener("pageshow", onVoiceCommandWake, true);
    showToast("Voice commands on and listening.", 3500);
    ensureVoiceCommandListening(false);
  }

  function uninstallVoiceCommand() {
    document.removeEventListener("keydown", onVcKeyDown, true);
    document.removeEventListener("visibilitychange", onVoiceCommandWake, true);
    window.removeEventListener("focus", onVoiceCommandWake, true);
    window.removeEventListener("pageshow", onVoiceCommandWake, true);
    vcManuallyPaused = false;
    if (!EXAM.active) stopListening();   // leave quiz-mode listening alone if a quiz is still running
    showToast("Voice commands off.");
  }

  // ═══════════════════════════════════════════════════════════════
  // SMART READER — intelligent DOM annotation (v0.3)
  //   For pages built without WCAG semantics: infer roles, labels and
  //   structure, stamp ARIA attributes, and detect repeating patterns
  //   (multiple-choice questions in particular) so the screen reader and
  //   voice commands can work where a normal screen reader cannot.
  // ═══════════════════════════════════════════════════════════════

  const SMART_SKIP = `#${TOAST_ID},#${ANNOUNCER_ID},#${MIC_INDICATOR_ID},#${STYLE_ID}`;
  const DONE_ATTR  = "data-extabilify-annotated";

  function smartSkippable(el) {
    return !el || !el.closest || el.closest(SMART_SKIP) != null;
  }

  function vText(el) {
    if (!el) return "";
    return (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
  }

  function smartHidden(el) {
    if (!el || !el.getBoundingClientRect) return true;
    let cs;
    try { cs = getComputedStyle(el); } catch (_) { return true; }
    if (cs.display === "none" || cs.visibility === "hidden") return true;
    const r = el.getBoundingClientRect();
    return r.width === 0 && r.height === 0;
  }

  function bodyFontSize() {
    return parseFloat(getComputedStyle(document.body).fontSize) || 16;
  }

  // ── Landmarks: header/nav/main/aside/footer/form/section ──────────────────
  function annotateLandmarks(root) {
    const roleMap = { HEADER:"banner", NAV:"navigation", MAIN:"main",
                      ASIDE:"complementary", FOOTER:"contentinfo", FORM:"form" };
    root.querySelectorAll(
      "header:not([" + DONE_ATTR + "]),nav:not([" + DONE_ATTR + "])," +
      "main:not([" + DONE_ATTR + "]),aside:not([" + DONE_ATTR + "])," +
      "footer:not([" + DONE_ATTR + "]),form:not([" + DONE_ATTR + "])"
    ).forEach(el => {
      if (smartSkippable(el)) return;
      if (!el.getAttribute("role") && roleMap[el.tagName]) {
        // banner/contentinfo only when a top-level element
        const scoped = /HEADER|FOOTER/.test(el.tagName);
        if (!scoped || !el.parentElement.closest("article,section,main,aside"))
          el.setAttribute("role", roleMap[el.tagName]);
      }
      if (!el.getAttribute("aria-label") && !el.getAttribute("aria-labelledby")) {
        const h = el.querySelector(":scope > h1, :scope > h2, :scope > h3, :scope > * > h1, :scope > * > h2");
        const t = vText(h).slice(0, 60);
        if (t) el.setAttribute("aria-label", t);
      }
      el.setAttribute(DONE_ATTR, "1");
    });
  }

  // ── Faux controls: clickable divs/spans without button semantics ─────────
  function annotateFauxControls(root) {
    const sel = ['[onclick]', '[role="button"]', '[role="tab"]', '[role="menuitem"]',
                 '[class*="btn" i]', '[class*="button" i]', '[class*="clickable" i]']
      .map(s => `${s}:not([${DONE_ATTR}])`).join(",");
    root.querySelectorAll(sel).forEach(el => {
      if (smartSkippable(el)) return;
      const tag = el.tagName;
      if (tag === "BUTTON" || tag === "A" || tag === "INPUT" ||
          tag === "SELECT" || tag === "TEXTAREA" || tag === "LABEL") {
        el.setAttribute(DONE_ATTR, "1"); return;
      }
      if (smartHidden(el)) return;
      // don't hijack a wrapper that already holds a real control
      if (el.querySelector("button,a[href],input,select,textarea")) {
        el.setAttribute(DONE_ATTR, "1"); return;
      }
      const txt = vText(el).slice(0, 80);
      if (!el.getAttribute("role")) el.setAttribute("role", "button");
      if (!el.hasAttribute("tabindex")) el.setAttribute("tabindex", "0");
      if (txt && !el.getAttribute("aria-label") && !el.getAttribute("aria-labelledby"))
        el.setAttribute("aria-label", txt);
      el.setAttribute(DONE_ATTR, "1");
    });
  }

  // ── Images / icons ──────────────────────────────────────────────────────
  function annotateImages(root) {
    root.querySelectorAll("img:not([alt]):not([" + DONE_ATTR + "])").forEach(el => {
      if (smartSkippable(el)) return;
      const link = el.closest("a[href]");
      const guess = (link && vText(link)) || el.getAttribute("title") ||
        (el.getAttribute("src") || "").split("/").pop().split(/[?#]/)[0]
          .replace(/\.\w+$/, "").replace(/[-_]+/g, " ").trim();
      el.setAttribute("alt", guess ? guess.slice(0, 80) : "");
      el.setAttribute(DONE_ATTR, "1");
    });
    root.querySelectorAll("svg:not([aria-label]):not([aria-hidden]):not([" + DONE_ATTR + "])").forEach(el => {
      if (smartSkippable(el)) return;
      const titled = el.querySelector("title");
      if (titled && vText(titled)) el.setAttribute("aria-label", vText(titled).slice(0, 60));
      else if (!el.closest("button,a[href],[role=button]")) el.setAttribute("aria-hidden", "true");
      el.setAttribute(DONE_ATTR, "1");
    });
  }

  // ── Unlabelled form fields ──────────────────────────────────────────────
  function annotateInputs(root) {
    root.querySelectorAll(
      "input:not([type=hidden]):not([type=radio]):not([type=checkbox]):not([" + DONE_ATTR + "])," +
      "select:not([" + DONE_ATTR + "]),textarea:not([" + DONE_ATTR + "])"
    ).forEach(el => {
      if (smartSkippable(el)) return;   // radios/checkboxes are handled by the quiz engine
      let named = el.getAttribute("aria-label") || el.getAttribute("aria-labelledby") || el.closest("label");
      if (!named && el.id) {
        try { named = document.querySelector(`label[for="${CSS.escape(el.id)}"]`); } catch (_) {}
      }
      if (!named) {
        const prev = el.previousElementSibling;
        const prevTxt = prev && vText(prev);
        const guess = el.getAttribute("placeholder") ||
          (prevTxt && prevTxt.length < 40 && !prev.matches("h1,h2,h3,h4,h5,h6,[role=heading]") ? prevTxt : "") ||
          (el.getAttribute("name") || "").replace(/[-_]+/g, " ").trim() ||
          (el.getAttribute("aria-describedby") ? "" : "");
        if (guess) el.setAttribute("aria-label", guess.slice(0, 60));
      }
      el.setAttribute(DONE_ATTR, "1");
    });
  }

  // ── Visually-styled text that acts as a heading but isn't marked up ──────
  function annotateHeadings(root) {
    const base = bodyFontSize();
    root.querySelectorAll(
      "p:not([" + DONE_ATTR + "]),div:not([" + DONE_ATTR + "]),span:not([" + DONE_ATTR + "])"
    ).forEach(el => {
      if (smartSkippable(el) || el.children.length > 0) return;
      const txt = vText(el);
      if (!txt || txt.length > 120) return;
      if (el.closest("h1,h2,h3,h4,h5,h6,a,button,label,[role=button],[role=heading]")) return;
      let cs; try { cs = getComputedStyle(el); } catch (_) { return; }
      if (!/^(block|flex|grid|list-item)$/.test(cs.display)) return;
      const size   = parseFloat(cs.fontSize) || 0;
      const weight = parseInt(cs.fontWeight, 10) || 400;
      if (size >= base * 1.4 && weight >= 600) {
        el.setAttribute("role", "heading");
        el.setAttribute("aria-level", size >= base * 2 ? "2" : "3");
        el.setAttribute(DONE_ATTR, "1");
      }
      // note: elements that are NOT headings are left unmarked so other
      // passes (faux controls, inputs) can still claim them.
    });
  }

  // ── Highest text-density block (for "read the main part") ────────────────
  function findDenseBlock() {
    let best = null, bestScore = 0;
    document.querySelectorAll("article,main,[role=main],section,div").forEach(el => {
      if (smartSkippable(el) || smartHidden(el)) return;
      const txt = vText(el);
      if (txt.length < 240) return;
      const linkLen = [...el.querySelectorAll("a")].reduce((s, a) => s + vText(a).length, 0);
      const nodes   = el.querySelectorAll("*").length || 1;
      const score   = ((txt.length - linkLen) / nodes) * Math.log(txt.length);
      if (score > bestScore) { bestScore = score; best = el; }
    });
    return best;
  }

  // ═══════════════════════════════════════════════════════════════
  // QUIZ MODE — detect multiple-choice questions and drive them by voice
  // ═══════════════════════════════════════════════════════════════

  function smartCommonAncestor(els) {
    let a = els[0];
    for (let i = 1; i < els.length && a; i++) {
      let b = els[i];
      while (a && !a.contains(b)) a = a.parentElement;
    }
    return a || document.body;
  }

  function optionLabelFor(input) {
    // 0. ARIA-native widgets usually carry their own label / text
    //    (ignore an aria-label we wrote on a previous scan pass)
    if (input.tagName !== "INPUT") {
      const authored = input.hasAttribute("data-extabilify-exam-opt")
        ? "" : input.getAttribute("aria-label");
      const own = authored || getAriaLabelledByText(input) || vText(input);
      if (own) return own;
    }
    // 1. explicit <label for="…">
    if (input.id) {
      try {
        const l = document.querySelector(`label[for="${CSS.escape(input.id)}"]`);
        if (l && vText(l)) return vText(l);
      } catch (_) {}
    }
    // 2. wrapping <label>
    const wrap = input.closest("label");
    if (wrap) {
      const c = wrap.cloneNode(true);
      c.querySelectorAll("input,select,textarea,button").forEach(n => n.remove());
      if (vText(c)) return vText(c);
    }
    // 3. author-supplied ARIA (ignore a label we wrote on a previous pass)
    const lbById = getAriaLabelledByText(input);
    if (lbById) return lbById;
    if (input.getAttribute("aria-label") && !input.hasAttribute("data-extabilify-exam-opt"))
      return input.getAttribute("aria-label");
    // 4. bare markup: text that follows the input, up to the next control/break
    const stop = n => n && n.nodeType === 1 && /^(INPUT|BR|LABEL|SELECT|TEXTAREA|HR)$/.test(n.tagName);
    let after = "";
    for (let n = input.nextSibling; n && !stop(n); n = n.nextSibling) {
      if (n.nodeType === 3) after += n.textContent;
      else if (n.nodeType === 1) after += " " + vText(n);
    }
    after = after.replace(/\s+/g, " ").trim();
    if (after) return after;
    // 5. text immediately before the input (label-after-then-input is rarer)
    let before = "";
    for (let n = input.previousSibling; n && !stop(n); n = n.previousSibling) {
      if (n.nodeType === 3) before = n.textContent + before;
      else if (n.nodeType === 1) before = vText(n) + " " + before;
    }
    before = before.replace(/\s+/g, " ").trim();
    if (before) return before;
    // 6. single-child parent
    if (input.parentElement &&
        input.parentElement.querySelectorAll("input").length === 1 &&
        vText(input.parentElement)) return vText(input.parentElement);
    return input.value || "no label";
  }

  function findStem(container, group) {
    const hinted = container.querySelector(
      '[class*="question" i],[class*="stem" i],[class*="prompt" i],[class*="query" i]'
    );
    if (hinted && vText(hinted) && !group.some(g => hinted.contains(g)))
      return vText(hinted).slice(0, 320);

    const legend = container.querySelector("legend");
    if (legend && vText(legend)) return vText(legend).slice(0, 320);

    let node = container;
    for (let hops = 0; hops < 4 && node; hops++) {
      let prev = node.previousElementSibling;
      while (prev) {
        const t = vText(prev);
        if (t && t.length > 8 && !/^[a-j][.)]?$/i.test(t) &&
            !prev.querySelector('input[type="radio"],input[type="checkbox"],[role="radio"],[role="checkbox"]'))
          return t.slice(0, 320);
        prev = prev.previousElementSibling;
      }
      node = node.parentElement;
    }

    const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, null);
    let n;
    while ((n = walker.nextNode())) {
      const t = n.textContent.replace(/\s+/g, " ").trim();
      const inOption = group.some(g => (g.closest("label") || g.parentElement || g).contains(n));
      if (t.length > 12 && !inOption) return t.slice(0, 320);
    }
    return "";
  }

  // A choice control is "usable" if it exists in the DOM, is not disabled, and
  // no ancestor is display:none / [hidden].  Native inputs that are merely
  // *visually* hidden (opacity:0, 1px, off-screen) — the norm for CSS-styled
  // radios — MUST still be included; we click their label to select them.
  function ancestorNotRendered(el) {
    for (let n = el; n && n !== document.documentElement; n = n.parentElement) {
      if (n.nodeType !== 1) break;
      if (n.hasAttribute("hidden")) return true;
      let cs; try { cs = getComputedStyle(n); } catch (_) { return false; }
      if (cs.display === "none") return true;
    }
    return false;
  }

  const CHOICE_SEL = 'input[type="radio"],input[type="checkbox"],[role="radio"],[role="checkbox"],[role="switch"]';
  const EXAM_GROUP_ATTR = "data-extabilify-exam-group";
  let examGroupSeq = 0;

  function examElementGroupKey(el, prefix) {
    if (!el.hasAttribute(EXAM_GROUP_ATTR)) {
      el.setAttribute(EXAM_GROUP_ATTR, String(++examGroupSeq));
    }
    return `${prefix}:${el.getAttribute(EXAM_GROUP_ATTR)}`;
  }

  function isChoiceControl(el) {
    if (el.tagName === "INPUT") return el.type === "radio" || el.type === "checkbox";
    const r = (el.getAttribute("role") || "").toLowerCase();
    return r === "radio" || r === "checkbox" || r === "switch";
  }

  function choiceType(el) {
    if (el.tagName === "INPUT") return el.type === "checkbox" ? "multi" : "single";
    const r = (el.getAttribute("role") || "").toLowerCase();
    return (r === "checkbox" || r === "switch") ? "multi" : "single";
  }

  function choiceChecked(el) {
    if (el.tagName === "INPUT") return !!el.checked;
    if (el.hasAttribute("data-extabilify-faux-choice") && fauxChoiceClassChecked(el)) return true;
    return el.getAttribute("aria-checked") === "true";
  }

  function fauxChoiceClassChecked(el) {
    const cls = typeof el.className === "string" ? el.className : "";
    return /\b(?:checked|selected|active|picked|chosen)\b/i.test(cls) ||
      el.getAttribute("data-checked") === "true" ||
      el.getAttribute("data-selected") === "true" ||
      el.getAttribute("aria-pressed") === "true";
  }

  function possibleFauxChoiceText(el) {
    const clone = el.cloneNode(true);
    clone.querySelectorAll("input,select,textarea,button,svg,img,.box,.dot,.check,.radio,.icon")
      .forEach(n => n.remove());
    return vText(clone) || vText(el);
  }

  function annotateFauxChoiceControls() {
    document.querySelectorAll(
      '.q,[class*="question" i],[class*="quiz" i],[class*="mcq" i],[data-question],[data-quiz]'
    ).forEach(container => {
      if (smartSkippable(container) || smartHidden(container)) return;
      if (container.querySelector(CHOICE_SEL)) return;
      const stem = container.querySelector('legend,[class*="question" i],[class*="stem" i],[class*="prompt" i],[class*="query" i]');
      if (!stem && !/^\s*(?:q\.?\s*)?\d+[\).:-]\s+\S/i.test(vText(container))) return;

      const candidates = [...container.querySelectorAll(
        '[data-choice],[data-option],[onclick],[role="button"],[class*="option" i],[class*="choice" i]'
      )].filter(el => {
        if (el === container || smartSkippable(el) || smartHidden(el)) return false;
        if (el.closest("button,a[href],label") || el.querySelector(CHOICE_SEL)) return false;
        const cls = typeof el.className === "string" ? el.className : "";
        if (/\b(?:stem|question|prompt|query|note|hint|submit|button|btn)\b/i.test(cls)) return false;
        const txt = possibleFauxChoiceText(el);
        return txt.length >= 1 && txt.length <= 160;
      });

      const unique = [];
      const seen = new Set();
      candidates.forEach(el => {
        const key = possibleFauxChoiceText(el).toLowerCase();
        if (seen.has(key)) return;
        seen.add(key);
        unique.push(el);
      });
      if (unique.length < 2 || unique.length > 12) return;

      container.setAttribute("role", "radiogroup");
      container.setAttribute("data-extabilify-faux-question", "true");
      unique.forEach(el => {
        el.setAttribute("role", "radio");
        el.setAttribute("tabindex", el.hasAttribute("tabindex") ? el.getAttribute("tabindex") : "0");
        el.setAttribute("data-extabilify-faux-choice", "true");
        el.setAttribute("aria-checked", fauxChoiceClassChecked(el) ? "true" : "false");
      });
    });
  }

  function choiceGroupKey(el, nameCounts) {
    if (el.tagName === "INPUT" && el.name && (nameCounts.get(el.name) || 0) > 1) {
      return "name:" + el.name;
    }
    const rg = el.closest('[role="radiogroup"],fieldset');
    if (rg) return examElementGroupKey(rg, "rg");

    for (let n = el.parentElement, depth = 0; n && n !== document.body && depth < 6; n = n.parentElement, depth++) {
      const controls = [...n.querySelectorAll(CHOICE_SEL)]
        .filter(x => isChoiceControl(x) && !ancestorNotRendered(x));
      if (controls.length < 2) continue;
      const cls = typeof n.className === "string" ? n.className : "";
      const hasQuestionHint =
        /\b(q|question|quiz|item|mcq|choice|answer|option)s?\b/i.test(cls) ||
        n.querySelector('legend,[class*="question" i],[class*="stem" i],[class*="prompt" i],[class*="query" i]');
      if (hasQuestionHint) return examElementGroupKey(n, "struct");
    }

    const anc = el.closest("fieldset,ul,ol,form,section,div,table,tbody");
    return anc ? examElementGroupKey(anc, "anc") : "anc:x";
  }

  function cssPath(el) {
    let p = el.tagName;
    let n = el, depth = 0;
    while (n.parentElement && depth < 4) { p += ">" + n.parentElement.tagName; n = n.parentElement; depth++; }
    return p;
  }

  function buildExamModel() {
    annotateFauxChoiceControls();
    const all = [...document.querySelectorAll(
      'input[type="radio"],input[type="checkbox"],' +
      '[role="radio"],[role="checkbox"],[role="switch"]'
    )];
    const inputs = all.filter(i => {
      if (smartSkippable(i) || !isChoiceControl(i)) return false;
      if (i.disabled || i.getAttribute("aria-disabled") === "true") return false;
      if (i.type === "hidden") return false;
      return !ancestorNotRendered(i);
    });
    if (!inputs.length) return [];

    const nameCounts = new Map();
    inputs.forEach(inp => {
      if (inp.tagName === "INPUT" && inp.name) nameCounts.set(inp.name, (nameCounts.get(inp.name) || 0) + 1);
    });

    // Group by valid shared control name, radiogroup/fieldset, or inferred
    // question wrapper when quiz builders give every radio a unique name.
    const groups = new Map();
    inputs.forEach(inp => {
      const key = choiceGroupKey(inp, nameCounts);
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(inp);
    });

    const questions = [];
    for (const [name, group] of groups) {
      if (group.length < 2) continue;
      const multi = group.filter(g => choiceType(g) === "multi").length;
      const type = multi > group.length / 2 ? "multi" : "single";
      let container = smartCommonAncestor(group);
      // Widen to a tidy question wrapper if one exists (so the stem is inside it)
      let up = container.parentElement;
      for (let i = 0; i < 2 && up && up !== document.body; i++) {
        const foreign = [...up.querySelectorAll(CHOICE_SEL)].some(x => !group.includes(x));
        if (!foreign &&
            (/question|quiz|q-?\d|item|mcq/i.test(up.className || "") ||
             up.querySelector('[class*="question" i],[class*="stem" i],legend'))) {
          container = up;
        }
        up = up.parentElement;
      }
      const stem = findStem(container, group) || "Question";
      const options = group.map((input, i) => ({
        letter: String.fromCharCode(65 + i),
        label: optionLabelFor(input).slice(0, 200),
        input
      }));
      questions.push({ id: 0, name, type, container, stem, options });
    }

    // Order by document position, then number
    questions.sort((a, b) => {
      const pos = a.container.compareDocumentPosition(b.container);
      return (pos & Node.DOCUMENT_POSITION_FOLLOWING) ? -1 :
             (pos & Node.DOCUMENT_POSITION_PRECEDING) ?  1 : 0;
    });
    questions.forEach((q, i) => {
      q.id = i + 1;
      if (!q.container.getAttribute("role")) q.container.setAttribute("role", "group");
      q.container.setAttribute("aria-label",
        `Question ${q.id} of ${questions.length}: ${q.stem.slice(0, 140)}`);
      q.container.setAttribute("data-extabilify-exam-q", String(q.id));
      q.options.forEach(o => {
        o.input.setAttribute("aria-label",
          `Question ${q.id}, option ${o.letter}: ${o.label}`);
        o.input.setAttribute("data-extabilify-exam-opt", o.letter);
      });
    });
    return questions;
  }

  function examAnsweredLetters(q) {
    return q.options.filter(o => choiceChecked(o.input)).map(o => o.letter);
  }

  // ── Reliable selection: works for native inputs (incl. visually-hidden and
  //    framework-controlled) and ARIA radio/checkbox widgets. One real
  //    activation only, so checkboxes never double-toggle. ──────────────────
  function selectChoice(input, wantChecked) {
    const isInput = input.tagName === "INPUT";
    const want = wantChecked !== false;

    // The element a sighted user would actually click.
    let clickTarget = input;
    if (isInput && input.id) {
      try {
        const l = document.querySelector(`label[for="${CSS.escape(input.id)}"]`);
        if (l) clickTarget = l;
      } catch (_) {}
    }
    if (clickTarget === input) {
      const w = input.closest("label");
      if (w) clickTarget = w;
    }

    try { input.scrollIntoView({ block: "center" }); } catch (_) {}
    try { (isInput ? input : clickTarget).focus({ preventScroll: true }); } catch (_) {}

    // 1. normal path — a single genuine click
    if (choiceChecked(input) !== want) {
      try { clickTarget.click(); } catch (_) {}
    }

    // 2. native input a framework ignored → set via prototype setter + notify
    if (isInput && choiceChecked(input) !== want) {
      try {
        const d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "checked");
        (d && d.set) ? d.set.call(input, want) : (input.checked = want);
      } catch (_) { try { input.checked = want; } catch (_) {} }
      ["input", "change"].forEach(t => {
        try { input.dispatchEvent(new Event(t, { bubbles: true })); } catch (_) {}
      });
      // A synthetic click's native default action always CHECKS a radio or
      // toggles a checkbox — dispatching one while trying to UNCHECK would
      // immediately undo the state we just set above. Only fire it when we
      // actually want the box checked (real bug: this used to run
      // unconditionally, so programmatically unchecking a sibling radio to
      // enforce single-choice — see examAnswer — silently failed, leaving
      // the previous answer checked alongside the new one).
      if (want) {
        try { input.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window })); } catch (_) {}
      }
    }

    // 3. ARIA widget that didn't move → dispatch a bubbling click, then force aria
    if (!isInput && choiceChecked(input) !== want) {
      try { input.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window })); } catch (_) {}
      if (choiceChecked(input) !== want) {
        try { setAriaChoiceState(input, want); } catch (_) {}
      }
    }

    if (!isInput && input.hasAttribute("data-extabilify-faux-choice")) {
      try { setAriaChoiceState(input, want); } catch (_) {}
    }

    return choiceChecked(input);
  }

  function setAriaChoiceState(input, want) {
    const role = (input.getAttribute("role") || "").toLowerCase();
    if (role === "radio" && want) {
      const group = input.closest('[role="radiogroup"],[data-extabilify-faux-question]');
      if (group) {
        group.querySelectorAll('[role="radio"]').forEach(el => {
          if (el !== input) el.setAttribute("aria-checked", "false");
        });
      }
    }
    input.setAttribute("aria-checked", want ? "true" : "false");
  }

  // Full NATO phonetic alphabet — quizzes rarely have more than 6-8 options,
  // but capping recognition at "J" meant any question with more options
  // than that (or an "eleven"/"twelve"-numbered option) silently had no way
  // to be answered at all past that point.
  const NATO = { alpha:"A", bravo:"B", charlie:"C", delta:"D", echo:"E", foxtrot:"F",
                 golf:"G", hotel:"H", india:"I", juliet:"J", kilo:"K", lima:"L",
                 mike:"M", november:"N", oscar:"O", papa:"P", quebec:"Q", romeo:"R",
                 sierra:"S", tango:"T", uniform:"U", victor:"V", whiskey:"W",
                 xray:"X", "x-ray":"X", yankee:"Y", zulu:"Z" };
  const HOMOPHONE = { a:"A", ay:"A", eh:"A", hey:"A",
                      b:"B", bee:"B", be:"B", bea:"B",
                      c:"C", see:"C", sea:"C", si:"C",
                      d:"D", dee:"D", di:"D",
                      e:"E", ee:"E",
                      f:"F", ef:"F", eff:"F",
                      g:"G", gee:"G", jee:"G",
                      h:"H", aitch:"H", h8:"H",
                      i:"I", eye:"I", aye:"I",
                      j:"J", jay:"J",
                      k:"K", kay:"K",
                      l:"L", el:"L", ell:"L",
                      m:"M", em:"M",
                      n:"N", en:"N",
                      o:"O", oh:"O",
                      p:"P", pee:"P",
                      q:"Q", cue:"Q", queue:"Q",
                      r:"R", ar:"R", are:"R",
                      s:"S", es:"S", ess:"S",
                      t:"T", tea:"T", tee:"T",
                      u:"U", you:"U", ewe:"U",
                      v:"V", vee:"V",
                      w:"W",
                      x:"X", ex:"X",
                      y:"Y", why:"Y",
                      z:"Z", zee:"Z", zed:"Z" };
  const NUMWORD = { one:1, two:2, to:2, too:2, three:3, four:4, for:4, five:5, six:6,
                    seven:7, eight:8, ate:8, nine:9, ten:10, eleven:11, twelve:12,
                    thirteen:13, fourteen:14, fifteen:15, sixteen:16, seventeen:17,
                    eighteen:18, nineteen:19, twenty:20 };

  function normalizeAnswerText(text) {
    return normalizeVoiceCommand(text)
      .replace(/^(?:option|answer|choice|letter|number|the)\s+/, "")
      .replace(/^[a-z]\s*[\).:-]\s+/, "")
      .replace(/\b(?:the|a|an)\b/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function optionMatchScore(spoken, label) {
    const s = normalizeAnswerText(spoken);
    const l = normalizeAnswerText(label);
    if (!s || !l) return 0;
    if (s === l) return 1;
    if (s.length >= 3 && l.includes(s)) return 0.92;
    if (l.length >= 3 && s.includes(l)) return 0.88;
    const sw = new Set(s.split(/\s+/).filter(w => w.length > 1));
    const lw = new Set(l.split(/\s+/).filter(w => w.length > 1));
    if (!sw.size || !lw.size) return 0;
    let overlap = 0;
    sw.forEach(w => { if (lw.has(w)) overlap++; });
    return overlap / Math.max(sw.size, lw.size);
  }

  function matchSpokenOption(spoken, q, silent) {
    if (!q || !q.options || !q.options.length) return "";
    const scored = q.options
      .map(o => ({ letter: o.letter, score: optionMatchScore(spoken, o.label) }))
      .filter(x => x.score >= 0.66)
      .sort((a, b) => b.score - a.score);
    if (!scored.length) return "";
    if (scored.length > 1 && Math.abs(scored[0].score - scored[1].score) < 0.08) {
      if (!silent) {
        const tied = scored.slice(0, 2).map(x => x.letter).join(" or ");
        sayThenListen(`I heard "${spoken}", but that could mean option ${tied}. Say the letter.`);
      }
      return "";
    }
    return scored[0].letter;
  }

  // Turn a spoken answer token into an option letter ("A".."Z"), or "" if none.
  function parseAnswerToken(tok) {
    if (!tok) return "";
    tok = tok.toLowerCase().replace(/[.\s]+$/,"").trim();
    if (/^[a-z]$/.test(tok)) return tok.toUpperCase();
    if (NATO[tok]) return NATO[tok];
    if (HOMOPHONE[tok]) return HOMOPHONE[tok];
    if (/^\d+$/.test(tok)) { const n = +tok; return n >= 1 && n <= 26 ? String.fromCharCode(64 + n) : ""; }
    if (NUMWORD[tok]) return String.fromCharCode(64 + NUMWORD[tok]);
    return "";
  }

  // The single place every answer-parsing path should go through. Tries the
  // actual option TEXT first, and only falls back to generic letter/NATO/
  // number parsing if nothing on the current question matches — because a
  // NATO/phonetic word can genuinely collide with real quiz content (e.g.
  // "Zulu" and "Ewe" are literal Ghanaian-language answer options in this
  // product's own bundled quiz, and also happen to be the NATO word for "Z"
  // and a homophone for "U" — saying "Zulu" must select the option labelled
  // Zulu, not silently resolve to letter Z). Short/bare tokens like "a" or
  // "bravo" naturally score 0 against real option text (optionMatchScore
  // ignores 1-character words), so this never interferes with normal
  // letter-based answering.
  function resolveAnswerToken(tok, q, silent) {
    return matchSpokenOption(tok, q, silent) || parseAnswerToken(tok);
  }

  // Split a checkbox-style multi-answer utterance into its separate answers —
  // "A and C", "Twi, Zulu and Ewe", "one and three" — and resolve each piece
  // (by letter, NATO word, number, or spoken option label) against the
  // current question. Returns null unless there are 2+ segments AND every
  // one of them resolves, so an ambiguous or partly-understood utterance
  // never silently selects only some of what was said.
  function parseMultiAnswerTokens(raw, q) {
    const segments = String(raw || "")
      .split(/\s*(?:,|&|\+|\band\b)\s*/i)
      .map(s => s.trim())
      .filter(Boolean);
    if (segments.length < 2) return null;
    const letters = [];
    for (const seg of segments) {
      const L = resolveAnswerToken(seg, q, true);
      if (!L) return null;
      if (!letters.includes(L)) letters.push(L);
    }
    return letters.length ? letters : null;
  }

  function examProgress() {
    const done = EXAM.questions.filter(q => examAnsweredLetters(q).length).length;
    return { done, total: EXAM.questions.length };
  }

  function setExamCurrent(container) {
    document.querySelectorAll("[data-extabilify-exam-current]")
      .forEach(n => n.removeAttribute("data-extabilify-exam-current"));
    if (container) container.setAttribute("data-extabilify-exam-current", "true");
  }

  function examCurrent() { return EXAM.questions[EXAM.index] || null; }

  function examRead(optionsOnly) {
    const q = examCurrent();
    if (!q) return;
    setExamCurrent(q.container);
    try { q.container.scrollIntoView({ behavior: "smooth", block: "center" }); } catch (_) {}
    const optsSpoken = q.options.map(o => `${o.letter}. ${o.label}`).join(". ");
    const chosen = examAnsweredLetters(q);
    const chosenSpoken = chosen.length
      ? ` You have chosen ${chosen.length > 1 ? "options " : "option "}${chosen.join(" and ")}.`
      : "";
    const lead = optionsOnly ? "" : `Question ${q.id} of ${EXAM.questions.length}. ${q.stem}. `;
    const hint = q.type === "multi"
      ? ` This is a checkbox question — choose all that apply. Say the letters together with "and", like "A and C", or one at a time, then say next.`
      : ` Say the letter of your answer.`;
    sayThenListen(`${lead}${optsSpoken}.${chosenSpoken}${hint}`);
  }

  function examStart() {
    EXAM.questions = buildExamModel();
    if (!EXAM.questions.length) {
      speakNarration("I could not find any multiple choice questions on this page.");
      return false;
    }
    EXAM.active = true;
    EXAM.index = 0;
    EXAM.submitArmed = false;
    EXAM.autoAdvancePending = false;
    initVcRecognition();                 // make sure the mic engine exists
    scheduleListen(4000);                // fallback: open mic even if speech stalls
    const n = EXAM.questions.length;
    speakNarration(
      `Quiz mode. ${n} question${n > 1 ? "s" : ""}. After each question, just say the letter of your answer. ` +
      `You can also say next, back, repeat, or submit. Say info progress any time to check how many are left.`,
      () => examRead()                   // read Q1, which then opens the mic
    );
    return true;
  }

  function examStop() {
    EXAM.active = false;
    // If general voice commands are on, drop back to continuous command
    // listening instead of going silent — only fully stop if they are off.
    if (!currentState.voiceCommand) stopListening();
    setExamCurrent(null);
    const p = examProgress();
    sayThenListen(`Leaving quiz mode. You answered ${p.done} of ${p.total} question${p.total > 1 ? "s" : ""}.`);
  }

  function examGo(delta) {
    if (!EXAM.active) return;
    // A single-choice answer just auto-advanced (and read) the next question
    // on its own. If the very next thing heard is a forward "next", the
    // student likely means the question they just heard, not the one after
    // it — advancing again would silently skip a question they never
    // answered. Treat this one "next" as a no-op confirmation instead.
    if (delta > 0 && EXAM.autoAdvancePending) {
      EXAM.autoAdvancePending = false;
      const q = examCurrent();
      sayThenListen(`You're on question ${q ? q.id : EXAM.index + 1} now. Say repeat to hear it again, or next to continue.`);
      return;
    }
    EXAM.autoAdvancePending = false;
    const ni = EXAM.index + delta;
    if (ni < 0) { sayThenListen("You are on the first question."); return; }
    if (ni >= EXAM.questions.length) {
      const p = examProgress();
      sayThenListen(p.done >= p.total
        ? `That was the last question. All ${p.total} answered. Say submit to finish.`
        : `That was the last question. ${p.done} of ${p.total} answered. Say submit, or go to a question number to fill the rest.`);
      return;
    }
    EXAM.index = ni;
    examRead();
  }

  function examGoTo(n) {
    if (!EXAM.active) return;
    EXAM.autoAdvancePending = false;
    if (!(n >= 1 && n <= EXAM.questions.length)) {
      sayThenListen(`There is no question ${n}. This quiz has ${EXAM.questions.length} questions.`);
      return;
    }
    EXAM.index = n - 1;
    examRead();
  }

  function examAnswer(letter) {
    const q = examCurrent();
    if (!q) return;
    EXAM.autoAdvancePending = false;
    const L = String(letter).toUpperCase();
    const opt = q.options.find(o => o.letter === L);
    if (!opt) {
      const last = q.options[q.options.length - 1].letter;
      sayThenListen(`Question ${q.id} has options A to ${last}. Which one?`);
      return;
    }

    if (q.type === "multi") {
      const want = !choiceChecked(opt.input);        // toggle
      selectChoice(opt.input, want);
      if (examAnsweredLetters(q).length) q.container.setAttribute("data-extabilify-exam-answered", "true");
      else q.container.removeAttribute("data-extabilify-exam-answered");
      sayThenListen(`${want ? "Added" : "Removed"} ${L}, ${opt.label}. ` +
        `Say another letter, or say next.`);
      return;
    }

    // single choice — explicitly uncheck every other option first. Native
    // same-`name` radios do this on their own, but buildExamModel also
    // groups radios/ARIA widgets that do NOT share a real browser radio
    // group (e.g. a quiz builder gave every option its own unique `name`;
    // see choiceGroupKey's "struct"/"anc" fallback). On those pages, without
    // this, an earlier answer stays checked alongside the new one — so a
    // later letter LOOKS like it was ignored because the option it replaced
    // never actually got cleared.
    q.options.forEach(o => {
      if (o !== opt && choiceChecked(o.input)) selectChoice(o.input, false);
    });
    const ok = selectChoice(opt.input, true);
    q.container.setAttribute("data-extabilify-exam-answered", "true");
    const p = examProgress();
    const last = EXAM.index + 1 >= EXAM.questions.length;

    if (!ok) {
      // extremely rare — selection genuinely refused
      sayThenListen(`I marked ${L}, ${opt.label}, but the page did not confirm it. ` +
        `Say repeat to check, or say next.`);
      return;
    }
    if (last) {
      sayThenListen(`${L}, ${opt.label}. That was the last question. ` +
        `${p.done} of ${p.total} answered. Say submit to finish, or back to review.`);
    } else {
      // auto-advance: confirm, then read the next question (which reopens the mic)
      speakNarration(`${L}, ${opt.label}.`, () => {
        if (!EXAM.active) return;
        EXAM.index = Math.min(EXAM.index + 1, EXAM.questions.length - 1);
        EXAM.autoAdvancePending = true;
        examRead();
      });
    }
  }

  // Check several checkbox options in one go — "A and C", "Twi and Zulu".
  // Unlike the single-letter path (which toggles), this always SELECTS the
  // named options: saying your answers together should never risk
  // deselecting one because it happened to already be checked.
  function examAnswerMulti(letters) {
    const q = examCurrent();
    if (!q || q.type !== "multi") return false;
    EXAM.autoAdvancePending = false;
    const added = [];
    const already = [];
    letters.forEach(L => {
      const opt = q.options.find(o => o.letter === L);
      if (!opt) return;
      if (choiceChecked(opt.input)) { already.push(`${L}`); return; }
      selectChoice(opt.input, true);
      added.push(`${L}, ${opt.label}`);
    });
    if (examAnsweredLetters(q).length) q.container.setAttribute("data-extabilify-exam-answered", "true");
    const parts = [];
    if (added.length) parts.push(`Added ${added.join(". ")}.`);
    if (already.length) parts.push(`${already.join(" and ")} ${already.length > 1 ? "were" : "was"} already selected.`);
    sayThenListen(`${parts.join(" ") || "Nothing to add."} Say another letter, or say next.`);
    return true;
  }

  function examSubmit() {
    const armed = EXAM.submitArmed;
    EXAM.submitArmed = false;
    const p = examProgress();
    if (p.done < p.total && !armed) {
      const missing = EXAM.questions.filter(q => !examAnsweredLetters(q).length).map(q => q.id);
      EXAM.submitArmed = true;
      sayThenListen(`Hold on. Question ${missing.join(", ")} not answered yet. ` +
        `Say go to question ${missing[0]}, or say submit again to send anyway.`);
      return;
    }
    const last = EXAM.questions[EXAM.questions.length - 1];
    const form = last && last.container.closest("form");
    let btn = form &&
      form.querySelector('button[type="submit"],input[type="submit"],button:not([type])');
    if (!btn) {
      btn = [...document.querySelectorAll('button,input[type="submit"],[role="button"],a[href]')]
        .find(b => /\b(submit|finish|send|hand in|done|complete|next)\b/i.test(vText(b) || b.value || ""));
    }
    stopListening();
    if (btn) {
      speakNarration("Submitting your answers now.");
      try { btn.focus({ preventScroll: true }); } catch (_) {}
      try { btn.click(); } catch (_) {}
    } else {
      speakNarration("I could not find a submit button. Please press it yourself, or say click submit.");
    }
  }

  // ── Keyboard shortcuts while smart reader is on ──────────────────────────
  function onSmartKeyDown(e) {
    if (!e.altKey || !e.shiftKey) return;
    const k = e.key.toLowerCase();
    if (k === "q") {
      e.preventDefault();
      EXAM.active ? examStop() : examStart();
      return;
    }
    if (!EXAM.active) return;
    if (k === "n")      { e.preventDefault(); examGo(1); }
    else if (k === "p") { e.preventDefault(); examGo(-1); }
    else if (/^[1-9]$/.test(e.key)) {
      e.preventDefault();
      examAnswer(String.fromCharCode(64 + parseInt(e.key, 10)));
    }
  }

  // ── Scan orchestration ──────────────────────────────────────────────────
  function runSmartScan() {
    try {
      const root = document.body;
      if (!root) return;
      annotateLandmarks(root);
      annotateImages(root);
      annotateInputs(root);
      annotateFauxControls(root);
      annotateHeadings(root);
      const before = EXAM.questions.length;
      // While a quiz is in progress, keep the model stable — rebuilding it would
      // swap out the option objects mid-answer. Only (re)build when idle.
      if (!EXAM.active) EXAM.questions = buildExamModel();
      return { before, after: EXAM.questions.length };
    } catch (_) { /* never break the host page */ }
  }

  function installSmartReader() {
    runSmartScan();
    if (smartObserver) smartObserver.disconnect();
    smartObserver = new MutationObserver(muts => {
      let added = false;
      for (const m of muts) {
        if (m.addedNodes && m.addedNodes.length) { added = true; break; }
      }
      if (!added) return;
      if (smartScanTimer) window.clearTimeout(smartScanTimer);
      smartScanTimer = window.setTimeout(runSmartScan, 600);
    });
    try { smartObserver.observe(document.body, { childList: true, subtree: true }); } catch (_) {}
    document.addEventListener("keydown", onSmartKeyDown, true);

    // Stay quiet if a quiz is already starting (it was toggled on for us).
    if (EXAM.active) return;
    const qn = EXAM.questions.length;
    speakWithProfile("smart_reader_on", qn
      ? `Smart reading is on. This page looks like a quiz with ${qn} question${qn > 1 ? "s" : ""}. ` +
        `Say "quiz mode", or press Alt Shift Q, to start.`
      : `Smart reading is on. I have labelled the buttons, headings, images and sections on this page.`);
  }

  function uninstallSmartReader() {
    if (smartObserver) { smartObserver.disconnect(); smartObserver = null; }
    if (smartScanTimer) { window.clearTimeout(smartScanTimer); smartScanTimer = null; }
    document.removeEventListener("keydown", onSmartKeyDown, true);
    if (!currentState.voiceCommand) stopListening();
    setExamCurrent(null);
    EXAM.active = false; EXAM.questions = []; EXAM.index = -1; EXAM.submitArmed = false;
    speakWithProfile("smart_reader_off", "Smart reading is off.");
  }

  // ═══════════════════════════════════════════════════════════════
  // BOOT
  // ═══════════════════════════════════════════════════════════════

  function loadStateFromStorage() {
    chrome.storage.local.get({ [STATE_KEY]: DEFAULT_STATE }, items => applyState(items[STATE_KEY]));
  }

  injectStyles();
  ensureToast();
  ensureAnnouncer();
  ensureMicIndicator();
  refreshVoices();
  syncSelectionCache();
  installSelectionObservers();
  loadStateFromStorage();
  loadVoiceProfile();

  if ("speechSynthesis" in window) window.speechSynthesis.onvoiceschanged = refreshVoices;

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes[STATE_KEY]) applyState(changes[STATE_KEY].newValue || DEFAULT_STATE);
    if (changes[VP_KEY])    voiceProfileMap = changes[VP_KEY].newValue || {};
  });

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || typeof message.type !== "string") return;

    if (message.type === "EXTABILIFY_GET_SELECTION") {
      syncSelectionCache();
      sendResponse({ ok:true, text:lastSelection.text, lang:lastSelection.lang, url:lastSelection.url, updatedAt:lastSelection.updatedAt });
      return;
    }
    if (message.type === "EXTABILIFY_SPEAK_TEXT") {
      const ok = speakSelectionText(message.text, message.lang);
      sendResponse({ ok, message: ok ? "Reading selected text." : "Could not read that selection." });
      return;
    }
    if (message.type === "EXTABILIFY_SHOW_TOAST") {
      if (typeof message.message === "string" && message.message.trim()) showToast(message.message.trim());
      sendResponse({ ok:true }); return;
    }
    if (message.type === "EXTABILIFY_START_VOICE_CMD") {
      const ok = ensureVoiceCommandListening(true);
      sendResponse({ ok }); return;
    }
    if (message.type === "EXTABILIFY_START_EXAM") {
      if (!currentState.smartReader) toggleStateKey("smartReader"); // enable observer in the background
      const ok = examStart();                                      // acts on the current DOM immediately
      sendResponse({ ok, count: EXAM.questions.length });
      return;
    }
  });
})();
